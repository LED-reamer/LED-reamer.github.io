#include "window.h"
#include <GLFW/glfw3.h>
#include <stdio.h>

#include "logging.h"

//TODO: replace these macros with own "module"
#include <stdlib.h>
#define MALLOC(size) malloc(size)
#define CALLOC(size) calloc(1, size)
#define FREE(ptr) free(ptr)


uint8_t glew_initialized = 0;
uint16_t num_windows = 0;
//only used to set glfwMakeContextCurrent(window);
window_t* current_window_context;

typedef struct
{
	int states[GLFW_KEY_LAST + 1];
}keyboard_state_t;

keyboard_state_t keyboard_state_1 = {0};
keyboard_state_t keyboard_state_2 = {0};
keyboard_state_t* keyboard_state_current = &keyboard_state_1;
keyboard_state_t* keyboard_state_previous = &keyboard_state_2;

typedef struct
{
	int states[GLFW_MOUSE_BUTTON_LAST + 1];
}mouse_state_t;

mouse_state_t mouse_state_1 = {0};
mouse_state_t mouse_state_2 = {0};
mouse_state_t* mouse_state_current = &mouse_state_1;
mouse_state_t* mouse_state_previous = &mouse_state_2;


window_t* window_create(const char* title, uint32_t width, uint32_t height)
{
	if(num_windows == 0)
	{
		if (!glfwInit())
		{
			ERROR("couldn't init glfw");
			return NULL;
		}
	}
	
	// use OpenGL 3.3
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

	
	//glfwWindowHint(GLFW_SAMPLES, 4);
	glfwWindowHint(GLFW_TRANSPARENT_FRAMEBUFFER, 1);
	//glfwWindowHint(GLFW_DECORATED, 0);
		
	window_t* window = glfwCreateWindow(width, height, title, NULL, NULL);
	window_set_current(window);
	
	if(glew_initialized == 0)
	{
		if (glewInit() != GLEW_OK)
		{
			ERROR("couldn't init glew");
			return NULL;
		}
		glew_initialized = 1;
	}
	num_windows++;
	return window;
}

void window_destroy(window_t* window)
{
	glfwDestroyWindow(window);
	
	num_windows--;
	if(num_windows == 0)
	{
		glfwTerminate();
	}
}

int window_open(window_t* window)
{
	//close if window was destroyed
	if(window == NULL)
	{
		ERROR("window_open was called while window was NULL");
		return 0;
	}

	
	return !glfwWindowShouldClose(window);
}

void __window_update_input_states(window_t* window)
{
	//keyboard
	//swap current and prev pointers
	keyboard_state_t* temp = keyboard_state_current;
	keyboard_state_current = keyboard_state_previous;
	keyboard_state_previous = temp;

	for (int i = 0; i < GLFW_KEY_LAST; i++)
	{
		keyboard_state_current->states[i] = glfwGetKey(window, i) == GLFW_PRESS;
	}

	//same for mouse
	mouse_state_t* temp2 = mouse_state_current;
	mouse_state_current = mouse_state_previous;
	mouse_state_previous = temp2;

	for (int i = 0; i < GLFW_MOUSE_BUTTON_LAST; i++)
	{
		mouse_state_current->states[i] = glfwGetMouseButton(window, i) == GLFW_PRESS;
	}
}

void window_update(window_t* window)
{
	if(window_open(window) != 1)
		glfwHideWindow(window); //don't show closed windows

	// we still want to update the closed window to prevent issues with window contexts

	window_set_current(window);
	glfwPollEvents();
	__window_update_input_states(window);

	uint32_t w, h = 0;
	window_get_size(window, &w, &h);
	glViewport(0, 0, w, h);
	
	if(window_get_mode(window) != WINDOW_MODE_MINIMIZED && window_open(window))
		glfwSwapBuffers(window);
}

void window_close(window_t* window)
{
	glfwSetWindowShouldClose(window, 1);
}

void window_set_current(window_t* window)
{
	if(window != current_window_context)
	{
		glfwMakeContextCurrent(window);
		current_window_context = window;
	}
}

void window_set_title(window_t* window, const char* title)
{
	glfwSetWindowTitle(window, title);
}

void window_get_size(window_t* window, uint32_t* width, uint32_t* height)
{
	glfwGetWindowSize(window, (int32_t*)width, (int32_t*)height);
}

void window_set_size(window_t* window, uint32_t width, uint32_t height)
{
	glfwSetWindowSize(window, width, height);
}

void window_get_position(window_t* window, int32_t* x, int32_t* y)
{
	glfwGetWindowPos(window, x, y);
}

void window_set_position(window_t* window, int32_t x, int32_t y)
{
	glfwSetWindowPos(window, x, y);
}

window_mode_e window_get_mode(window_t* window)
{
	if(glfwGetWindowAttrib(window, GLFW_ICONIFIED))
		return WINDOW_MODE_MINIMIZED;
		
	if(glfwGetWindowAttrib(window, GLFW_MAXIMIZED))
		return WINDOW_MODE_MAXIMIZED;

	return WINDOW_MODE_NORMAL;
	
}

void window_set_mode(window_t* window, window_mode_e mode)
{
	switch(mode)
	{
		case WINDOW_MODE_NORMAL:
			glfwRestoreWindow(window);
			break;
		case WINDOW_MODE_MAXIMIZED:
			glfwMaximizeWindow(window);
			break;
		case WINDOW_MODE_MINIMIZED:
			glfwIconifyWindow(window);
			break;
		default:
			break;
	}
}

int window_is_focused(window_t* window)
{
	return glfwGetWindowAttrib(window, GLFW_FOCUSED);
}

void window_set_vsync(window_t* window, int interval)
{
	window_set_current(window);
	glfwSwapInterval(interval);
}

void window_get_attention(window_t* window)
{
	glfwRequestWindowAttention(window);
}

void window_set_icon(window_t* window, void* pixel_data, uint32_t width, uint32_t height)
{
	//TODO: you could set multiple resolutions here
	GLFWimage icons[1];
	icons[0].pixels = pixel_data;
	icons[0].width = width;
	icons[0].height = height;
	glfwSetWindowIcon(window, 1, icons);
}

double window_get_time_seconds()
{
	return glfwGetTime();
}

void window_set_time_seconds(double new_time)
{
	glfwSetTime(new_time);
}

void window_get_keyboard_states(window_t* window, void** current, void** previous)
{
	*current = (void*)keyboard_state_current;
	*previous = (void*)keyboard_state_previous;
}

void window_get_mouse_states(window_t* window, void** current, void** previous)
{
	*current = (void*)mouse_state_current;
	*previous = (void*)mouse_state_previous;
}

window_t* window_get_current()
{
	return current_window_context;
}
