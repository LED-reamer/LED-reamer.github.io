#pragma once
#include <stdint.h>

typedef float color_t[4];
typedef uint32_t hex_color_t;
