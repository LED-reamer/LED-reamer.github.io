#include "ui.h"

#include "gfx.h"
#include "font.h"
#include "dynamic_array.h"
#include "macros.h"
#include "logging.h"
#include "types.h"

//TODO: fix this
#include <stdlib.h>
#define MALLOC malloc
#define FREE free
//

u32 TEMP_COUNTER = 0;

ui_style_t ui_style_get_default_dark()
{
	ui_style_t style = { 0 };
	V4_SET(style.font_color, 1, 1, 1, 1);
	V4_SET(style.container_style.color_0, 0.0, 0.0, 0.0, 1);
	V4_SET(style.container_style.color_1, 0.07f, 0.07f, 0.07f, 1);
	V4_SET(style.container_style.color_2, 0.14f, 0.14f, 0.14f, 1);
	V4_SET(style.container_style.color_3, 0.21f, 0.21f, 0.21f, 1);
	V4_SET(style.container_style.color_4, 0.28f, 0.28f, 0.28f, 1);
	V4_SET(style.container_style.color_5, 0.35f, 0.35f, 0.35f, 1);
	style.container_style.rounding = 10.0f;
	style.container_style.padding_top = 5.0f;
	style.container_style.padding_bottom = 5.0f;
	style.container_style.padding_left = 5.0f;
	style.container_style.padding_right = 5.0f;

	return style;
}

ui_t* ui_init()
{
	ui_t* ui = MALLOC(sizeof(ui_t));

	ui->style_default = ui_style_get_default_dark();

	ui_container_t root = { 0 };
	root.children = array_create(uint32_t, 0, 10);
	
	ui->containers = array_create(ui_container_t, 0, 10);
	array_push(ui->containers, root);

	return ui;
}

void ui_update(ui_t* ui, vec4 root_container_rectangle)
{
	LOG_UINT(TEMP_COUNTER);
	TEMP_COUNTER = 0;
	ui->containers[0].rectangle[0] = root_container_rectangle[0];
	ui->containers[0].rectangle[1] = root_container_rectangle[1];
	ui->containers[0].rectangle[2] = root_container_rectangle[2];
	ui->containers[0].rectangle[3] = root_container_rectangle[3];
	
	size_t num_containers = array_len(ui->containers);
	for (size_t i = 0; i < num_containers; i++)
	{
		ui_container_t* container = &ui->containers[i];

		ui_style_t* style;
		if(container->style == NULL)
			style = &ui->style_default;
		else
			style = container->style;
		ui_container_style_t* container_style = &style->container_style;
		
		color_t color;
		switch(container->child_depth)
		{
			case 0:
				V4_COPY(color, container_style->color_0);break;
			case 1:
				V4_COPY(color, container_style->color_1);break;
			case 2:
				V4_COPY(color, container_style->color_2);break;
			case 3:
				V4_COPY(color, container_style->color_3);break;
			case 4:
				V4_COPY(color, container_style->color_4);break;
			case 5:
				V4_COPY(color, container_style->color_5);break;
			default:
				V4_COPY(color, container_style->color_5);break;
		}

		if(container_style->rounding == 0.0f)
		{
			gfx_draw_rectangle(
				(vec2){container->rectangle[0], container->rectangle[1]}, 
				(vec2){container->rectangle[2], container->rectangle[3]}, 
				color);
		}
		else
		{
			gfx_draw_rectangle_rounded(
				(vec2){container->rectangle[0], container->rectangle[1]}, 
				(vec2){container->rectangle[2], container->rectangle[3]}, 
				container_style->rounding, color);
		}
		
		
		array_resize(ui->containers[i].children, 0);
	}

	array_resize(ui->containers, 1);// index 0 is reserved for root
	//reset root
	ui->containers[0].children_weight = 0.0f;
}

void ui_destroy(ui_t* ui)
{
	for (size_t i = 0; i < array_len(ui->containers); i++)
	{
		array_destroy(ui->containers[i].children);
	}
	array_destroy(ui->containers);
	FREE(ui);
}

void __update_container_children_sizes(ui_t* ui, uint32_t parent)
{
	ui_container_t* parent_container = &ui->containers[parent];
	size_t num_children = array_len(parent_container->children);

	float accumulated_weight = 0;
	
	for(size_t i = 0; i < num_children; i++)
	{
		TEMP_COUNTER++;
		ui_container_t* container = &ui->containers[parent_container->children[i]];
		
		if(parent_container->orientation == UI_VERTICAL)
		{
			container->rectangle[0] = parent_container->rectangle[0];
			container->rectangle[1] = parent_container->rectangle[1] + (parent_container->rectangle[3] * (accumulated_weight/parent_container->children_weight));
			container->rectangle[2] = parent_container->rectangle[2];
			container->rectangle[3] = parent_container->rectangle[3] * (container->weight/parent_container->children_weight);
		}
		if(parent_container->orientation == UI_HORIZONTAL)
		{
			container->rectangle[0] = parent_container->rectangle[0] + (parent_container->rectangle[2] * (accumulated_weight/parent_container->children_weight));
			container->rectangle[1] = parent_container->rectangle[1];
			container->rectangle[2] = parent_container->rectangle[2] * (container->weight/parent_container->children_weight);
			container->rectangle[3] = parent_container->rectangle[3];
		}
		accumulated_weight += container->weight;

		//padding
		container->rectangle[0] += container->style->container_style.padding_left;
		container->rectangle[1] += container->style->container_style.padding_top;
		container->rectangle[2] -= container->style->container_style.padding_right*2;
		container->rectangle[3] -= container->style->container_style.padding_bottom*2;
	}
}

uint32_t ui_container_add(ui_t* ui, uint32_t parent/*0 -> root*/, ui_orientation_e orientation, float weight, ui_style_t* style/*nullable*/)
{
	ui_container_t container = { 0 };
	container.index = (uint32_t)array_len(ui->containers);
	container.parent = parent;
	container.children = array_create(uint32_t, 0, 10);
	array_push(ui->containers[container.parent].children, container.index);
	container.child_depth = ui->containers[parent].child_depth + 1;
	ui->containers[parent].children_weight += weight;
	container.weight = weight;
	container.orientation = orientation;
	
	if(style == NULL)
		container.style = &ui->style_default;
	else
		container.style = style;//if NULL use standard style
	
	array_push(ui->containers, container);
	__update_container_children_sizes(ui, container.parent);

	return container.index;
}
