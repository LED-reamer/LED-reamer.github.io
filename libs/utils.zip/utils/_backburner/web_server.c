#include "web_server.h"
#define LIBNET_IMPLEMENTATION
#include "net.h"
#include "logging.h"

#include <pthread.h>
#include <signal.h>
#include <string.h>

//TODO: fix this
#include <stdlib.h>
#define MALLOC malloc
#define REALLOC realloc
#define FREE free
//

void web_server_init()
{
	net_init();
}

void web_server_terminate()
{
	net_shutdown();
}

typedef struct
{
	http_request_method_e method;
	const char* route;
	void (*function)(web_server_route_args_t*, web_server_route_response_t*);
}route_t;

struct web_server_t
{
	uint8_t running;
	net_socket_t server;
	pthread_t accept_thread;
	size_t num_routes;
	route_t routes[WEB_SERVER_MAX_ROUTES];
};

web_server_t* web_server_create()
{
	web_server_t* web_server = MALLOC(sizeof(web_server_t));
	web_server->running = 0;
	web_server->num_routes = 0;

	return web_server;
}

void web_server_add_route(web_server_t* web_server, http_request_method_e method, 
							const char* route, void (*function)(web_server_route_args_t*,
							web_server_route_response_t*))
{
	web_server->routes[web_server->num_routes] = (route_t){ .method = method, .route = route, .function = function};
	web_server->num_routes++;
}


void accept_loop(web_server_t* server);
void web_server_start(web_server_t* web_server, uint32_t port)
{
	web_server->running = 1;
	net_tcp_socket_open(&web_server->server, port, 0, 1);

	if(net_tcp_make_socket_ready(&web_server->server) == -1)
	{
		ERROR("Could not create server socket");
	}
	
	#ifndef _WIN32
	int optval = 1;
	setsockopt(web_server->server.handle, SOL_SOCKET, SO_REUSEADDR, &optval, sizeof(optval));
	setsockopt(web_server->server.handle, SOL_SOCKET, SO_REUSEPORT, &optval, sizeof(optval));
	#endif
	
	pthread_create(&web_server->accept_thread, NULL, (void*)accept_loop, web_server);
}

void web_server_stop(web_server_t* web_server)
{
	web_server->running = 0;
}

uint8_t web_server_running(web_server_t* web_server)
{
	return web_server->running;
}

void web_server_destroy(web_server_t* web_server)
{
	web_server->running = 0;
	pthread_kill(web_server->accept_thread, SIGSTOP);
	net_socket_close(&web_server->server);
	
	FREE(web_server);
}


//threaded functions
typedef struct
{
	web_server_t* server;
	uint8_t* running;
	net_socket_t client;
	net_address_t client_address;
	char receive_buffer[WEB_SERVER_BUFFER_SIZE];
	
}handle_thread_args_t;

void handle_request(handle_thread_args_t* args)
{
	http_request_t http = http_parse(args->receive_buffer);
	for(size_t i = 0; i < args->server->num_routes; i++)
	{
		if(args->server->routes[i].route != NULL)
		{
			if(0 == strcmp(http.request_uri, args->server->routes[i].route) && http.method == args->server->routes[i].method)
			{
				web_server_route_args_t route_args = { .http = &http };
				web_server_route_response_t route_response = { .send_buffer = { 0 } };
				args->server->routes[i].function(&route_args, &route_response);

				if(http.method == HTTP_GET)
					net_tcp_socket_send(&args->client, route_response.send_buffer, strlen(route_response.send_buffer));
			}
		}
	}
	http_free(&http);
	net_socket_close(&args->client);
}

void accept_loop(web_server_t* server)
{
	char receive_buffer[WEB_SERVER_BUFFER_SIZE];
	net_address_t client_address;
	net_socket_t client;
	while(server->running)
	{
		if(net_get_error() != NULL)
		{
			ERROR("Web server socket error: %s", net_get_error());
			exit(1);
		}
		
		if(net_tcp_accept(&server->server, &client, &client_address) == 0)
		{
			memset(receive_buffer, 0, WEB_SERVER_BUFFER_SIZE);
			net_tcp_socket_receive(&client, receive_buffer, WEB_SERVER_BUFFER_SIZE);

			//start handle thread
			pthread_t handle_thread;
			handle_thread_args_t handle_thread_args = {
				.server = server,
				.running = &server->running,
				.client = client,
				.client_address = client_address
			};
			
			memcpy(handle_thread_args.receive_buffer, receive_buffer, WEB_SERVER_BUFFER_SIZE);
			pthread_create(&handle_thread, NULL, (void*)handle_request, &handle_thread_args);
		}
	}
}
