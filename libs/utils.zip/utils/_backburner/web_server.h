//linux only

#pragma once
#include "http.h"
#include <stdint.h>

#define WEB_SERVER_BUFFER_SIZE 1024 * 1024
#define WEB_SERVER_MAX_ROUTES 1000

typedef struct web_server_t web_server_t;

typedef struct
{
	http_request_t* http;
}web_server_route_args_t;

typedef struct
{
	char send_buffer[WEB_SERVER_BUFFER_SIZE];
}web_server_route_response_t;

void web_server_init();
void web_server_terminate();

web_server_t* web_server_create();
void web_server_add_route(web_server_t* web_server, http_request_method_e method, const char* route, void (*function)(web_server_route_args_t*, web_server_route_response_t*));
void web_server_start(web_server_t* web_server, uint32_t port);
void web_server_stop(web_server_t* web_server);
uint8_t web_server_running(web_server_t* web_server);
void web_server_destroy(web_server_t* web_server);
