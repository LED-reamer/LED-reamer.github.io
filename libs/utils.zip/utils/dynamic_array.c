#include "dynamic_array.h"

#include "logging.h"

// TODO: handle this
#include <stdlib.h>
#define MALLOC malloc
#define REALLOC realloc
#define FREE free
//

typedef struct
{
	size_t item_count;
	size_t item_size;  // fixed value
	size_t chunk_size; // fixed value
}array_header_t;

#define array_header(a) ((array_header_t *)(a)-1)

__attribute__((no_sanitize_address))
void* __array_create(size_t item_size, size_t item_count, size_t items_per_chunk)
{
	void *ptr = 0;
	size_t size = item_size * items_per_chunk + sizeof(array_header_t);
	array_header_t *header = MALLOC(size);

	if (header)
	{
	  header->item_count = item_count;
	  header->item_size = item_size;
	  header->chunk_size = item_size * items_per_chunk;
	  ptr = header + 1;
	}
	ptr = array_resize(ptr, item_count);
	return ptr;
}

__attribute__((no_sanitize_address))
void array_destroy(void *array) { FREE(array_header(array)); }

size_t __chunks_needed(size_t chunk_size, size_t item_size, size_t item_count)
{
	return ((item_size * item_count) / chunk_size) + 1;
}

__attribute__((no_sanitize_address))
void* array_resize(void* array, size_t new_item_count)
{
	array_header_t *h = array_header(array);
	array_header_t *new_header = REALLOC(h, sizeof(array_header_t) + h->chunk_size * __chunks_needed(h->chunk_size, h->item_size, new_item_count));
	if (!new_header)
	{
	  ERROR("Could not allocate extra dynamic array memory");
	  return NULL;
	}

	new_header->item_count = new_item_count;

	void *ptr = new_header + 1;
	return ptr;
}

__attribute__((no_sanitize_address))
size_t array_len(void *array) { return array_header(array)->item_count; }



