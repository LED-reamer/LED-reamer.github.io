#pragma once
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>


typedef struct
{
	size_t size;
	void* data;

	//buffer reading (for parsing etc)
	size_t read_offset;
}buffer_t;

buffer_t* buffer_create();
void buffer_destroy(buffer_t* buffer);

//data handling
void buffer_copy_data(buffer_t* buffer, void* data, size_t size);//auto resizes
void buffer_reserve_memory(buffer_t* buffer, size_t size);
void buffer_free_data(buffer_t* buffer);
void buffer_load_data_from_file(buffer_t* buffer, const char* filename);
void buffer_load_data_from_file_ptr(buffer_t* buffer, FILE* file);

//buffer reading --- all functions advance the read_offset
void buffer_set_offset(buffer_t* buffer, size_t new_offset);
void* buffer_read(buffer_t* buffer, size_t size);
uint8_t buffer_read_uint8(buffer_t* buffer);
int8_t buffer_read_int8(buffer_t* buffer);
uint16_t buffer_read_uint16(buffer_t* buffer);
int16_t buffer_read_int16(buffer_t* buffer);
uint32_t buffer_read_uint32(buffer_t* buffer);
int32_t buffer_read_int32(buffer_t* buffer);
uint64_t buffer_read_uint64(buffer_t* buffer);
int64_t buffer_read_int64(buffer_t* buffer);
float buffer_read_f32(buffer_t* buffer);
double buffer_read_double(buffer_t* buffer);
