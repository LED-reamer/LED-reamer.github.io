#include "input.h"
#include "window.h"
#include <GLFW/glfw3.h>


GLFWcursor* current_cursor = NULL;


typedef struct
{
	int states[GLFW_KEY_LAST + 1];
}keyboard_state_t;

typedef struct
{
	int states[GLFW_MOUSE_BUTTON_LAST + 1];
}mouse_state_t;

int key_down(window_t* window, key_e key)
{
	if (glfwGetKey(window, key) == GLFW_PRESS)
			return 1;
		return 0;
}

int key_just_down(window_t* window, key_e key)
{
	keyboard_state_t* current;
	keyboard_state_t* prev;
	window_get_keyboard_states(window, (void*)&current, (void*)&prev);
	return current->states[key] && !prev->states[key];
}

int key_just_released(window_t* window, key_e key)
{
	keyboard_state_t* current;
	keyboard_state_t* prev;
	window_get_keyboard_states(window, (void*)&current, (void*)&prev);
	return !current->states[key] && prev->states[key];
}

int mouse_button_down(window_t* window, mouse_button_e mouse_button)
{
	return glfwGetMouseButton(window, mouse_button) == GLFW_PRESS;
}

int mouse_button_just_down(window_t* window, mouse_button_e mouse_button)
{
	mouse_state_t* current;
	mouse_state_t* prev;
	window_get_mouse_states(window, (void*)&current, (void*)&prev);
	return current->states[mouse_button] && !prev->states[mouse_button];
}

int mouse_button_just_released(window_t* window, mouse_button_e mouse_button)
{
	mouse_state_t* current;
	mouse_state_t* prev;
	window_get_mouse_states(window, (void*)&current, (void*)&prev);
	return !current->states[mouse_button] && prev->states[mouse_button];
}

void mouse_get_position(window_t* window, double* x, double* y)
{
	glfwGetCursorPos(window, x, y);
}

void mouse_get_position_global(window_t* window, double* x, double* y)
{
	mouse_get_position(window, x, y);
	int32_t win_x, win_y;
	window_get_position(window, &win_x, &win_y);
	x += win_x;
	y += win_y;
}

int mouse_on_window(window_t* window)
{
	return glfwGetWindowAttrib(window, GLFW_HOVERED);
}

void mouse_hide(window_t* window, uint8_t hide)
{
	if(hide)
		glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_HIDDEN);
	else
		glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_NORMAL);
}

void mouse_raw_motion_active(window_t* window, uint8_t active)
{
	if (glfwRawMouseMotionSupported())
	    glfwSetInputMode(window, GLFW_RAW_MOUSE_MOTION, active);
}

void mouse_cursor_set_image(window_t* window, void* pixel_data, uint32_t width, uint32_t height, int32_t x_tip, int32_t y_tip)
{
	if(current_cursor != NULL)
		glfwDestroyCursor(current_cursor);
	
	GLFWimage image;
	image.pixels = pixel_data;
	image.width = width;
	image.height = height;
	
	current_cursor = glfwCreateCursor(&image, (int)x_tip, (int)y_tip);
	
	glfwSetCursor(window, current_cursor);
}

void mouse_cursor_set_standard_image(window_t* window, mouse_cursor_standard_e shape)
{
	if(current_cursor != NULL)
		glfwDestroyCursor(current_cursor);

	current_cursor = glfwCreateStandardCursor(shape);
	glfwSetCursor(window, current_cursor);
}
