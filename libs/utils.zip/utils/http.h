#pragma once
#include <stddef.h>

typedef enum
{
	HTTP_GET,
	HTTP_HEAD,
	HTTP_POST,
	HTTP_PUT,
	HTTP_DELETE,
	HTTP_CONNECT,
	HTTP_OPTIONS,
	HTTP_TRACE,
}http_request_method_e;

typedef struct
{
	char* field;
	char* data;
}http_header_field_t;

typedef struct
{
	//header
	http_request_method_e method;
	char* request_uri;
	char* http_version;
	size_t field_count;
	http_header_field_t* header_fields;

	//body
	size_t body_size;
	char* data;
}http_request_t;

void http_free(http_request_t* http_request);
http_request_t http_parse(char* request_string);
char* http_get_header_field(http_request_t* http_request, char* type);
