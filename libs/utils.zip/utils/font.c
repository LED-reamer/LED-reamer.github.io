#include "font.h"

#include "logging.h"
#define STB_TRUETYPE_IMPLEMENTATION
#include "3rd-party/stb_truetype.h"

#include <stdio.h>
#include <math.h>

//TODO fix this
#include <stdlib.h>
#define MALLOC malloc
#define CALLOC calloc
#define FREE free
//

static const int32_t first_ascii_char = 32;
static const int32_t last_ascii_char = 127;//last char is actually 126: "~"

font_t* font_load(const char* filepath, int32_t font_size)
{
	size_t file_size;
	uint8_t* file_buffer;
	    
	FILE* file = fopen(filepath, "rb");
	if(!file)
	{
		ERROR("Couldn't load font file \"%s\"", filepath);
		return NULL;
	}
		
	fseek(file, 0, SEEK_END);
	file_size = ftell(file); /* how long is the file ? */
	fseek(file, 0, SEEK_SET); /* reset */
	file_buffer = MALLOC(file_size);
	fread(file_buffer, file_size, 1, file);
	fclose(file);
	
	font_t* font = font_load_from_memory(file_buffer, font_size);
	
	FREE(file_buffer);
	return font;
}

font_t* font_load_from_memory(uint8_t* data, int32_t font_size)
{
	
	stbtt_fontinfo info;
	if (!stbtt_InitFont(&info, data, 0))
	{
		ERROR("Couldn't load font from memory");
	    return NULL;
	}
	float scale = stbtt_ScaleForPixelHeight(&info, font_size);
	int ascent, descent, line_gap;
	stbtt_GetFontVMetrics(&info, &ascent, &descent, &line_gap);

	int32_t x = 0;
	int32_t y = 0;

	int b_w = 0;
	int b_h = font_size;
	
	for	(int32_t i = first_ascii_char; i < last_ascii_char; i++)
	{
		int ax;
		int lsb;
		stbtt_GetCodepointHMetrics(&info, i, &ax, &lsb);
		b_w += roundf(ax * scale);
	}
	
	uint8_t* bitmap = CALLOC(b_w * b_h * sizeof(uint8_t), 1);//needs to be 0 initialized!
	if(!bitmap)
	{
		ERROR("Couldn't allocate enough memory for font bitmap");
	}
	
	ascent = roundf(ascent * scale);
	descent = roundf(descent * scale);

	font_t* font = MALLOC(sizeof(font_t));

	for (int32_t i = first_ascii_char; i < last_ascii_char; i++)
	{
		int32_t ax;
		int32_t lsb;
		stbtt_GetCodepointHMetrics(&info, i, &ax, &lsb);
		int32_t c_x1, c_y1, c_x2, c_y2;
		stbtt_GetCodepointBitmapBox(&info, i, scale, scale, &c_x1, &c_y1, &c_x2, &c_y2);
		
		y = ascent + c_y1;
		int32_t byte_offset = x + roundf(lsb * scale) + (y * b_w);
		
		stbtt_MakeCodepointBitmap(&info, bitmap + byte_offset, c_x2 - c_x1, c_y2 - c_y1, b_w, scale, scale, i);
		
		font->glyph_rects[i-first_ascii_char][0] = x;
		font->glyph_rects[i-first_ascii_char][1] = 0;
		
		x += roundf(ax * scale);
		font->glyph_rects[i-first_ascii_char][2] = x;
		font->glyph_rects[i-first_ascii_char][3] = font_size;
	}

	//convert to gl texture
	font->atlas = texture_create(b_w, b_h, TEXTURE_CHANNELS_R, 8);
	glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
	texture_set_pixels(font->atlas, b_w, b_h, bitmap);
	glPixelStorei(GL_UNPACK_ALIGNMENT, 4);

	FREE(bitmap);
	font->line_height = font_size;
	return font;
}

void font_get_character_size(font_t* font, char character, int32_t out_rect[2])
{
	out_rect[0] = font->glyph_rects[character - first_ascii_char][2] - font->glyph_rects[character - first_ascii_char][0];
	out_rect[1] = font->glyph_rects[character - first_ascii_char][3] - font->glyph_rects[character - first_ascii_char][1];
}

void font_get_string_size(font_t* font, const char* string, int32_t out_rect[2])
{
	out_rect[0] = 0;
	out_rect[1] = 0;
	
	char c;
	size_t index = 0;
	while(1)
	{
		c = string[index++];
		if (c == '\0') break;
		int32_t size[2];
		font_get_character_size(font, c, size);
		out_rect[0] += size[0];
		out_rect[1] = fmax(out_rect[1], size[1]);
	}
}

void font_get_character_on_atlas(font_t* font, char character, int32_t out_rect[4])
{
	out_rect[0] = font->glyph_rects[character - first_ascii_char][0];
	out_rect[1] = font->glyph_rects[character - first_ascii_char][1];
	out_rect[2] = font->glyph_rects[character - first_ascii_char][2];
	out_rect[3] = font->glyph_rects[character - first_ascii_char][3];
}

void font_destroy(font_t* font)
{
	texture_destroy(font->atlas);
	FREE(font);
}
