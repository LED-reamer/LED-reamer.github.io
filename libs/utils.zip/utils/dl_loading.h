//link with -ldl
//works at least on linux. has untested support for windows

#pragma once

void* dl_load(char* file_name);
void dl_close(void* dl);
void* dl_get_symbol(void* dl, char* symbol_string);
char* dl_error();
