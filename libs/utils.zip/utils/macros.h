#pragma once

#define cast_ptr(void_ptr, type_ptr) ((type_ptr)void_ptr)
