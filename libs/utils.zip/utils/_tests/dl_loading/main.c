#include "../../dl_loading.h"
#include <stdio.h>

//int my_func(int p1, int p2);

#include <dlfcn.h>

int main()
{
	void* lib = dl_load("./lib.so");
	//void* lib = dl_load("/home/tim/dev/c/first_server/src/testing/dynamic_library_loading/lib.so");

	char* ret = dl_error();
	if(ret != NULL)
	{
		printf("error: %s\n", ret);
	}

	int (*my_func)(int, int) = dl_get_symbol(lib, "example_func");

	printf("%i + %i = %i\n", 60, 9, my_func(60, 9));

	
	dl_close(lib);

	return 0;
}
