#include "example_lib.h"

int example_func(int param1, int param2)
{
	return param1 + param2;
}
