#pragma once


static int data_example[] = {16, 5, 2005};

int example_func(int param1, int param2);
