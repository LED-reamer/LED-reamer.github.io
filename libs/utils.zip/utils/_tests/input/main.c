#include "../../window.h"
#include "../../input.h"
#include "../../logging.h"

int main()
{
	window_t* win = window_create("win", 1600, 900);

	mouse_cursor_set_standard_image(win, MOUSE_CURSOR_HAND);
	
	
	double mx = 0.0;
	double my = 0.0;
	
	while(window_open(win))
	{
		window_update(win);
		
		mouse_get_position(win, &mx, &my);
		LOG("mouse x: %f, y: %f", mx, my);

		if(key_down(win, KEY_W))
		{
			LOG("hide mouse");
			mouse_hide(win, 1);
		}

		if(key_just_down(win, KEY_SPACE))
		{
			LOG("SUCCESSS");
		}

		if(key_just_released(win, KEY_SPACE))
		{
			LOG("YAHOOOOOOO");
		}

		if(mouse_button_down(win, MOUSE_BUTTON_1))
		{
			LOG("mousy lol");
		}

		if(mouse_button_just_down(win, MOUSE_BUTTON_2))
		{
			LOG("mousy SUCCESSS");
		}
		
		if(mouse_button_just_released(win, MOUSE_BUTTON_2))
		{
			LOG("mousy YAHOOOOOOO");
		}

		if(key_just_down(win, KEY_ESCAPE)) window_close(win);
		
	}

	window_destroy(win);
	return 0;
}
