#include "../../window.h"
#include "../../gl_wrapper.h"
#include "../../logging.h"
#include "../../image.h"


#include <stdlib.h>

char* vertex = "#version 330 core\n"\
"layout (location = 0) in vec3 aPos;\n"\
"layout (location = 1) in vec3 aColor;\n"\
"layout (location = 2) in vec2 aUv;\n"\
"out vec3 ourColor;\n"\
"out vec2 TexCoord;\n"\
"void main()\n"\
"{\n"\
"	gl_Position = vec4(aPos, 1.0);\n"\
"	ourColor = aColor;\n"\
"	TexCoord = aUv;\n"\
"}\0";

char* fragment = "#version 330 core\n"\
"out vec4 FragColor;\n"\
"in vec3 ourColor;\n"\
"in vec2 TexCoord;\n"\
"uniform sampler2D texture1;\n"\
"void main()\n"\
"{\n"\
"	FragColor = vec4(ourColor, 1.0) * texture(texture1, TexCoord);\n"\
"}\0";

float vertices[] = {
    // positions          // colors           // texture coords
     0.5f,  0.5f, 0.0f,   1.0f, 0.0f, 0.0f,   1.0f, 1.0f,   // top right
     0.5f, -0.5f, 0.0f,   0.0f, 1.0f, 0.0f,   1.0f, 0.0f,   // bottom right
    -0.5f, -0.5f, 0.0f,   0.0f, 0.0f, 1.0f,   0.0f, 0.0f,   // bottom left
    -0.5f,  0.5f, 0.0f,   1.0f, 1.0f, 0.0f,   0.0f, 1.0f    // top left 
};

uint32_t indices[] = {
        0, 1, 3, // first triangle
        1, 2, 3  // second triangle
};
int main()
{
	window_t* win = window_create("GFX", 1600, 900);
	shader_t shader = shader_create(vertex, fragment, NULL, NULL, NULL, NULL);
	shader_bind(shader);
	shader_uniform_int32(shader, "texture1", 0);
	mesh_t* mesh = mesh_create();
	vertex_attribute_e attribs[3] = { VERTEX_ATTRIB_FLOAT3, VERTEX_ATTRIB_FLOAT3, VERTEX_ATTRIB_FLOAT2 };
	mesh_set_attributes(mesh, attribs, 3);
	mesh_set_data_vertices(mesh, vertices, 4);
	mesh_set_data_indices(mesh, indices, 6);


	image_t* img = image_load("picture.png", 1, 0);
	texture_t* texture = texture_create(img->width, img->height, TEXTURE_CHANNELS_RGBA, img->bits_per_channel);
	texture_set_pixels(texture, img->width, img->height, img->pixels);
	image_destroy(img);


	//load pixels from texture
	image_t* img2 = malloc(sizeof(image_t));
	img2->width = texture->width;
	img2->height = texture->height;
	img2->channels = texture_get_num_channels(texture);
	img2->bits_per_channel = texture->bits_per_channel;
	img2->pixels = malloc(img2->width * img2->height * img2->channels * (img2->bits_per_channel / 8));
	texture_get_pixels(texture, img2->pixels);

	image_save(img2, IMAGE_JPG, "success.jpg");
	
	//cleanup
	free(img2->pixels);
	free(img2);
	
	window_t* win2 = window_create("GFX2", 1600, 900);

	
	

	while(window_open(win) || window_open(win2))
	{
		window_set_current(win);
		gl_render_state_reset();
		gl_state()->polygon_mode = GL_POLYGON_MODE_LINE;
		gl_state()->line_width = 10.0f;
		gl_render_state_apply();
		glClearColor(0.1f, 0.1f, 0.1f, 1.0f);
		glClear(GL_COLOR_BUFFER_BIT);
		shader_bind(shader);
		texture_bind(texture, 0);
		mesh_draw(mesh, 1, DRAW_MODE_TRIANGLES, 0);
		
		window_update(win);

		
		window_update(win2);
		glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
		glClear(GL_COLOR_BUFFER_BIT);
		
	}


	
	mesh_destroy(mesh);
	shader_destroy(shader);
	window_destroy(win);
	texture_destroy(texture);
	return 0;
}
