#include "../../window.h"
#include "../../gl_wrapper.h"
#include "../../logging.h"
#include "../../input.h"
#include "../../gfx.h"
#include "../../image.h"
#include "../../font.h"

#include <stdlib.h>
#define MALLOC malloc
#define FREE free


int main()
{
	window_t* win = window_create("TEXT!", 1600, 900);
	//font_t* font = font_load("Inter-Medium.ttf", 64);
	font_t* font = font_load("SketchBook.ttf", 64);

	//image_t* img = MALLOC(sizeof(image_t));
	//img->width = font->atlas->width;
	//img->height = font->atlas->height;
	//img->channels = 1;
	//img->bits_per_channel = 8;
	//img->pixels = MALLOC(img->width * img->height * sizeof(uint8_t));
	//texture_get_pixels(font->atlas, img->pixels);
	//image_save(img, IMAGE_PNG, "out.png");
	//	
	//FREE(img);
	//int32_t out_rect[2];
	//font_get_character_size(font, '$', out_rect);
	

	while(window_open(win))
	{
		window_update(win);

		gl_render_state_reset();
		gl_state()->caps[GL_CAP_CULL_FACE] = 1;
		gl_render_state_apply();
		gfx_clear((vec4){.1, .1, .1, 1});
		gfx_render();

		gfx_draw_string("PLAY", font, (vec2){100, 100}, (vec4){1, 1, 1, 1});
		gfx_draw_string("SETTINGS", font, (vec2){100, 200}, (vec4){1, 1, 1, 1});
		gfx_draw_string("CREDITS timmy", font, (vec2){100, 300}, (vec4){1, 1, 1, 1});
		gfx_draw_texture(font->atlas->gl_texture, (vec2){100, 0}, (vec2){font->atlas->width, font->atlas->height});
		//gfx_draw_character('$', font, (vec3){0, 0, 0}, (vec3){out_rect[0], 0, 0}, (vec3){0, out_rect[1], 0}, (vec3){out_rect[0], out_rect[1], 0}, (vec4){1, 1, 1, .3});
		

		if(key_just_down(win, KEY_ESCAPE))
			window_close(win);
	}
	font_destroy(font);
	window_destroy(win);
	gfx_destroy();
	return 0;
}











