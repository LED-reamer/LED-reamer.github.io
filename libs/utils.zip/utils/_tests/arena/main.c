#include "../../arena.h"
#include "../../logging.h"

void log_arena(arena_t* arena)
{
	LOG_SIZE(arena->num_start_chunks);
	LOG_SIZE(arena->num_chunks);
	LOG_SIZE(arena->chunk_size);
	LOG_PTR(arena->data);
	LOG_PTR(arena->current_pos);
}

int main(void)
{
	
	arena_t* arena = arena_create(1024, 3);

		
	LOG("--setup %zu bytes--", arena->num_chunks * arena->chunk_size);
	log_arena(arena);
	
	const size_t allocation_size = 2048;
	
	for(int i = 0; i < 20000;i++)
	{
		
		LOG("\n--alloc %zu bytes-- %i", allocation_size, i+1);
		arena_alloc(arena, allocation_size);
		log_arena(arena);
	}


	LOG("--RESET--");
	arena_reset(arena);
	log_arena(arena);

	arena_destroy(arena);
	
	return 0;
}
