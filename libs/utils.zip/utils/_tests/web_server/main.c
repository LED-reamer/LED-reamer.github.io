#include "../../web_server.h"
#include "../../logging.h"
#include <string.h>

void func_get(web_server_route_args_t* args, web_server_route_response_t* response)
{
	LOG("%s", http_get_header_field(args->http, "Host"));

	const char* answer = "HTTP/1.1 200 OK\nContent-Type: text/html; charset=utf-8\n"
	"<!doctype html>"
	"<html>"
	"<head>"
	"<meta charset=\"utf-8\">"
	"</head>"
	"<body>"
	"TEST"
	"</body>"
	"</html>";
	
	strcpy(response->send_buffer, answer);
	LOG("%s", response->send_buffer);
}

void func_post(web_server_route_args_t* args, web_server_route_response_t* response)
{
	LOG("POST function ptr was called!");
	const char* answer = "HTTP/1.1 200 OK\nContent-Type: text/html; charset=utf-8\nlol";
	strcpy(response->send_buffer, answer);
	LOG("%s", response->send_buffer);
}

int main()
{
	web_server_init();

	web_server_t* server = web_server_create();
	web_server_add_route(server, HTTP_GET, "/api/getting", &func_get);
	web_server_add_route(server, HTTP_GET, "/api/posting", &func_post);
	
	web_server_start(server, 8080);
	while(web_server_running(server))
	{
		switch(getchar())
		{
			case 'q':
				LOG("EXITING");
				web_server_stop(server);
				break;
			default:
				LOG("enter \"q\" to quit");
				break;
		}
	}
	web_server_destroy(server);

	web_server_terminate();
	
	return 0;
}
