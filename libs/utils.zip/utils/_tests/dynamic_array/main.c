#include "../../dynamic_array.h"
#include "../../logging.h"
#include <stdint.h>

void log_array(int* arr)
{
	for	(size_t i = 0; i < array_len(arr); i++)
	{
		LOG_INT(arr[i]);
	}
}

typedef struct
{
	uint32_t value1;
	uint32_t value2;
	uint32_t value3;
	float value4x;
	float value4y;
	float value4z;

	uint32_t* arr;
}my_struct_t;


int main()
{
	goto test_two;//[][][[][][][[][]]]



	
	int* arr = array_create(int, 8, 10);

	LOG_SIZE(array_len(arr));
	for	(size_t i = 0; i < array_len(arr); i++)
	{
		arr[i] = i;
	}

	log_array(arr);

	for (int i = 0; i < 1000000; i++)
	{
		array_push(arr, i);
	}

	for	(int i = 0; i < 1000;i++)
	{
		array_pop(arr);
	}
	
	
	log_array(arr);
	array_destroy(arr);

	LOG("DONE WITH TEST ONE");
  test_two:

	my_struct_t* arr2 = array_create(my_struct_t, 0, 10);

	for (size_t i = 0; i < 5000; i++)
	{
		my_struct_t s = { 0 };
		s.arr = array_create(uint32_t, 0, 10);
		
		array_push(arr2, s);
		
		array_len(arr2);

		LOG_SIZE(array_len(arr2));
	}
	array_resize(arr2[0].arr, 0);
	array_len(arr2[0].arr);
	array_resize(arr2, 0);

	array_destroy(arr2);
	LOG("DONE WITH TEST TWO");
	
	return 0;
}
