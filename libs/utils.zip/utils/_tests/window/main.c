#include "../../window.h"
#include "../../image.h"
#include "../../logging.h"


int main(void)
{
	window_t* win = window_create("sick", 1600, 900);
	window_t* win2 = window_create("sick2", 1600, 900);
	image_t* img = image_load("image.png", 0, 4);
	
	window_set_icon(win, img->pixels, img->width, img->height);

	image_destroy(img);
	

	//window_set_mode(win, WINDOW_MODE_MINIMIZED);
	window_set_vsync(win, 1);
	while (window_open(win) || window_open(win2))
	{
		window_update(win);
		glClearColor(1, 0, 0, 1);
		glClear(GL_COLOR_BUFFER_BIT);


		//uint32_t data = (uint32_t)window_is_focused(win);
		//LOG("%u\n", data);
		window_update(win2);
	}

	window_destroy(win);
	window_destroy(win2);

	return 0;
}
