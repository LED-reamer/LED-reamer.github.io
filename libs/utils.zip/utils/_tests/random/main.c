#include "../../random.h"
#include "../../logging.h"


int main(void)
{
	for (size_t i = 0; i < 1000; i++)
	{
		char* uuid = random_uuid();
		LOG("%s", uuid);
	}
	
	return 0;
}
