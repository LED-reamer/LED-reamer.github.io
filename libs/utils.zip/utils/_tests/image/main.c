#include "../../image.h"

int main()
{
	image_t* img = image_load("picture.png");

	image_save(img, IMAGE_PNG, "saved.png");

	image_destroy(img);
	return 0;
}
