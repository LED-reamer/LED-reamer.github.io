#include "../../ui.h"
#include "../../window.h"
#include "../../logging.h"
#include "../../input.h"
#include "../../gfx.h"
#include "../../types.h"


int main()
{
	window_t* win = window_create("UI", 1600, 900);
	ui_t* ui = ui_init();

	double prev = 0;
	double curr = 0;

	while(window_open(win))
	{
		prev = curr;
		curr = window_get_time_seconds();

		double diff = curr - prev;
		//LOG_FLOAT(1/diff);
		
		
		window_update(win);
		uint32_t w, h;
		window_get_size(win, &w, &h);
		gfx_clear(V4(0, 0, 0, 1));
			
		{
			uint32_t panel = ui_container_add(ui, 0, UI_HORIZONTAL, 300, NULL);
			uint32_t panel2 = ui_container_add(ui, 0, UI_VERTICAL, 100, NULL);
			ui_container_add(ui, ui_container_add(ui, panel2, UI_VERTICAL, 1, NULL), UI_VERTICAL, 1, NULL);
			
			
			uint32_t panel_a = ui_container_add(ui, panel, UI_VERTICAL, 1, NULL);
			ui_container_add(ui, panel, UI_HORIZONTAL, 5, NULL);

			for (uint i = 0; i < 10; i++)
			{
				ui_container_add(ui, panel_a, UI_VERTICAL, 1, NULL);
			}
		}

		
		ui_update(ui, V4(0, 0, w, h));
		
		gfx_render();

		if(key_just_down(win, KEY_ESCAPE))
			window_close(win);
			
		if(key_just_down(win, KEY_F10))
		{
			if(window_get_mode(win) == WINDOW_MODE_MINIMIZED || window_get_mode(win) == WINDOW_MODE_NORMAL)
				window_set_mode(win, WINDOW_MODE_MAXIMIZED);
			else
				window_set_mode(win, WINDOW_MODE_NORMAL);
		}
	}
	ui_destroy(ui);
	window_destroy(win);
	gfx_destroy();
	return 0;
}
