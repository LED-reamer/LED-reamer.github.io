#include "../../3rd-party/ufbx.h"
#include "../../buffer.h"
#include "../../logging.h"
#include <stdio.h>
#include <stdlib.h>

int main()
{
	buffer_t* buf = buffer_create();
	buffer_load_data_from_file(buf, "untitled.fbx");
	
	ufbx_load_opts opts = { 
		.target_axes = ufbx_axes_right_handed_y_up,
	  	.target_unit_meters = 1.0f
	}; // Optional, pass NULL for defaults
	ufbx_error error; // Optional, pass NULL if you don't care about errors
	
	ufbx_scene *scene = ufbx_load_memory(buf->data, buf->size, &opts, &error);
	
	
	if (!scene)
	{
	    fprintf(stderr, "Failed to load: %s\n", error.description.data);
	    exit(1);
	}
	
	for (size_t i = 0; i < scene->nodes.count; i++)
	{
	    ufbx_node *node = scene->nodes.data[i];
	    if (node->is_root) continue;
	
	    printf("Object: %s\n", node->name.data);
	    if (node->mesh) {
	        printf("-> mesh with %zu faces\n", node->mesh->faces.count);
	    }
	}
	
	ufbx_free_scene(scene);
	buffer_destroy(buf);
	
	return 0;
}
