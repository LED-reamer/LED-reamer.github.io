#include "../../window.h"
#include "../../gl_wrapper.h"
#include "../../logging.h"
#include "../../input.h"
#include "../../gfx.h"
#include "../../image.h"
#include "../../types.h"

static vec2 points[5] = {
	{0, 0},
	{10, 17},
	{8, 18},
	{59, 100},
	{1300, 970},
};

int main()
{
	window_t* win = window_create("GFX", 1600, 900);
	
	image_t* img = image_load("bg.jpg", 1, IMAGE_RGBA);
	texture_t* tex = texture_create(img->width, img->height, TEXTURE_CHANNELS_RGBA, img->bits_per_channel);
	texture_filtering(tex, TEXTURE_FILTERING_LINEAR, TEXTURE_FILTERING_LINEAR);
	texture_set_pixels(tex, img->width, img->height, img->pixels);
	image_destroy(img);

	render_target_t* rt = render_target_create(1920, 1080, TEXTURE_CHANNELS_RGBA, 8);

	while(window_open(win))
	{
		double x, y;
		mouse_get_position(win, &x, &y);
		window_update(win);

		gl_render_state_reset();
		gl_state()->caps[GL_CAP_CULL_FACE] = 1;
		gl_render_state_apply();
		
		render_target_bind(rt);
		gfx_clear((vec4){1, 0, 0, 1});
		gfx_draw_texture(tex->gl_texture, (vec2){0, 0}, (vec2){rt->texture->width, rt->texture->height});
		gfx_draw_line((vec2){0, 0}, (vec2){x, y}, 20, (vec4){1, 0, 0, 1});
		gfx_draw_lines(points, 5, 3, (vec4){0, 1, 0, 1});

		gfx_draw_cirlce((vec2){x, y}, 20, (vec4){0, 1, 1, 1});

		gfx_draw_texture(tex->gl_texture, (vec2){250, 0}, (vec2){200, 200});
		gfx_draw_texture_from_points(tex->gl_texture, (vec3) { 0, 0, 0 }, (vec3) { 500, 0, 0 }, (vec3) { 0, 500, 0 }, (vec3) { 500, 500, 0 }, (color_t) { 1, 1, 1, 1 }, (vec2) {tex->width, tex->height}, (vec4) { 1000, 1000, 100, 100 });
		
		gfx_draw_rectangle_rounded((vec2){0, 500}, (vec2){500.0f, 250.0f}, 10, (vec4){0.3f, 0.3f, 0.3f, 1.0f});
		gfx_render();
		render_target_unbind();
		
		gfx_clear(V4(1, 1, 1, 1));
		gfx_draw_texture(rt->texture->gl_texture, V2(0, 0), V2(x, y));
		gfx_render();
		

		if(key_just_down(win, KEY_ESCAPE))
			window_close(win);
			
		if(key_just_down(win, KEY_F10))
		{
			if(window_get_mode(win) == WINDOW_MODE_MINIMIZED || window_get_mode(win) == WINDOW_MODE_NORMAL)
				window_set_mode(win, WINDOW_MODE_MAXIMIZED);
			else
				window_set_mode(win, WINDOW_MODE_NORMAL);
		}
				


	}
	window_destroy(win);
	gfx_destroy();
	return 0;
}
