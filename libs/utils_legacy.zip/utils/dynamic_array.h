//platform independend code
//includes:
//	logging.h

#pragma once
#include <stddef.h>

#define array_create(type, item_count, items_per_chunk) __array_create(sizeof(type), item_count, items_per_chunk)
#define array_push(array, value) do {\
	array = array_resize(array, array_len(array) + 1);\
	array[array_len(array)-1] = value;\
	} while(0)
#define array_pop(array) do {\
		if(array_len(array) != 0)\
		array = array_resize(array, array_len(array)-1);\
	} while(0)

//use macro instead
void* __array_create(size_t item_size, size_t item_count, size_t items_per_chunk);

void array_destroy(void* array);
void* array_resize(void* array, size_t new_item_count);
size_t array_len(void* array);
