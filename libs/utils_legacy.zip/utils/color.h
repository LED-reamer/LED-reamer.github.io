#pragma once

typedef float color_t[4];
//typedef uint32_t hex_color_t;
