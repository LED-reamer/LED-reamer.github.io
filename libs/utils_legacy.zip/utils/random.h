#pragma once
#include <stdint.h>

void random_set_seed(uint32_t seed);
uint32_t random_get_seed();
float random_float(float min, float max);
int32_t random_int32(int32_t min, int32_t max);
uint32_t random_uint32(uint32_t min, uint32_t max);


typedef struct
{
	char string[37];
}uuid_t;
uuid_t random_uuid();
