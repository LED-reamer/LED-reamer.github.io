#include "random.h"
#include <stdlib.h>
#include <time.h>
#include <stdint.h>

uint32_t current_seed = 0;

void random_set_seed(uint32_t seed)
{
	srand(seed);
	current_seed = seed;
}

uint32_t random_get_seed()
{
	return current_seed;
}

float random_float(float min, float max)
{
	if(current_seed == 0)
		random_set_seed(time(0));

	return ((rand() / (float)RAND_MAX) * (max - min)) + min;
}

int32_t random_int32(int32_t min, int32_t max)
{
	if(current_seed == 0)
		random_set_seed(time(0));
	
	return (int32_t)((rand() / (float)RAND_MAX) * (1 + max - min)) + min;
}

uint32_t random_uint32(uint32_t min, uint32_t max)
{
	if(current_seed == 0)
		random_set_seed(time(0));
	
	return (uint32_t)((rand() / (float)RAND_MAX) * (1 + max - min)) + min;
}

uuid_t random_uuid()
{
	if(current_seed == 0)
		random_set_seed(time(0));
	
	char v[] = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};
	//3fb17ebc-bc38-4939-bc8b-74f2443281d4
	//8 dash 4 dash 4 dash 4 dash 12
	//char buf[37] = {0};
	uuid_t uuid = {0};
	
	//gen random for all spaces because lazy
	for(int i = 0; i < 36; ++i)
	{
	    uuid.string[i] = v[rand()%16];
	}
	
	//put dashes in place
	uuid.string[8] = '-';
	uuid.string[13] = '-';
	uuid.string[18] = '-';
	uuid.string[23] = '-';
	
	//needs end byte
	uuid.string[36] = '\0';
	
	return uuid;
}
