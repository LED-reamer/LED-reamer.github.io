#include "gl_wrapper.h"
#include "logging.h"
#include <string.h>
#include <stdint.h>

//TODO: move later
#include <stdlib.h>
#define MALLOC(size) malloc(size)
#define CALLOC(size) calloc(1, size)
#define FREE(ptr) free(ptr)
//


typedef enum
{
    SHADER_VERTEX,
    SHADER_FRAGMENT,
    SHADER_GEOMETRY,
    SHADER_TESS_CONTROL,
    SHADER_TESS_EVAL,
    SHADER_COMPUTE
}shader_type_e;

shader_t shader_create(const char* vertex, const char* fragment, const char* geometry, const char* tess_control, const char* tess_eval, const char* compute)
{
    uint32_t shader_objects[6] = { 0 };

    // Vertex Shader
    if (vertex != NULL && strlen(vertex) > 0)
    {
        uint32_t vertex_shader_object = glCreateShader(GL_VERTEX_SHADER);
        glShaderSource(vertex_shader_object, 1, (const char * const*)&vertex, NULL);
        glCompileShader(vertex_shader_object);

        int32_t compile_status;
        glGetShaderiv(vertex_shader_object, GL_COMPILE_STATUS, &compile_status);

        if (compile_status == GL_FALSE)
        {
            int32_t info_log_length;
            glGetShaderiv(vertex_shader_object, GL_INFO_LOG_LENGTH, &info_log_length);

            int8_t* info_log = (int8_t*)MALLOC(info_log_length);
            glGetShaderInfoLog(vertex_shader_object, info_log_length, NULL, info_log);

            ERROR("Vertex shader compilation failed: %s", info_log);

            glDeleteShader(vertex_shader_object);
            FREE(info_log);

            return 0;
        }
        shader_objects[SHADER_VERTEX] = vertex_shader_object;
    }
    
    // Fragment Shader
    if (fragment != NULL && strlen(fragment) > 0)
    {
        uint32_t fragment_shader_object = glCreateShader(GL_FRAGMENT_SHADER);
        glShaderSource(fragment_shader_object, 1, (const char * const*)&fragment, NULL);
        glCompileShader(fragment_shader_object);

        int32_t compile_status;
        glGetShaderiv(fragment_shader_object, GL_COMPILE_STATUS, &compile_status);

        if (compile_status == GL_FALSE)
        {
            int32_t info_log_length;
            glGetShaderiv(fragment_shader_object, GL_INFO_LOG_LENGTH, &info_log_length);

            int8_t* info_log = (int8_t*)MALLOC(info_log_length);
            glGetShaderInfoLog(fragment_shader_object, info_log_length, NULL, info_log);

            ERROR("Fragment shader compilation failed: %s", info_log);

            glDeleteShader(fragment_shader_object);
            FREE(info_log);

            return 0;
        }

        shader_objects[SHADER_FRAGMENT] = fragment_shader_object;
    }

    // Geometry Shader
    if (geometry != NULL && strlen(geometry) > 0)
    {
        uint32_t geometry_shader_object = glCreateShader(GL_GEOMETRY_SHADER);
        glShaderSource(geometry_shader_object, 1, (const char * const*)&geometry, NULL);
        glCompileShader(geometry_shader_object);

        int32_t compile_status;
        glGetShaderiv(geometry_shader_object, GL_COMPILE_STATUS, &compile_status);

        if (compile_status == GL_FALSE)
        {
            int32_t info_log_length;
            glGetShaderiv(geometry_shader_object, GL_INFO_LOG_LENGTH, &info_log_length);

            int8_t* info_log = (int8_t*)MALLOC(info_log_length);
            glGetShaderInfoLog(geometry_shader_object, info_log_length, NULL, info_log);

            ERROR("Geometry shader compilation failed: %s", info_log);

            glDeleteShader(geometry_shader_object);
            FREE(info_log);

            return 0;
        }

        shader_objects[SHADER_GEOMETRY] = geometry_shader_object;
    }

    // Tessellation Control Shader
    if (tess_control != NULL && strlen(tess_control) > 0)
    {
        uint32_t tess_control_shader_object = glCreateShader(GL_TESS_CONTROL_SHADER);
        glShaderSource(tess_control_shader_object, 1, (const char * const*)&tess_control, NULL);
        glCompileShader(tess_control_shader_object);

        int32_t compile_status;
        glGetShaderiv(tess_control_shader_object, GL_COMPILE_STATUS, &compile_status);

        if (compile_status == GL_FALSE)
        {
            int32_t info_log_length;
            glGetShaderiv(tess_control_shader_object, GL_INFO_LOG_LENGTH, &info_log_length);

            int8_t* info_log = (int8_t*)MALLOC(info_log_length);
            glGetShaderInfoLog(tess_control_shader_object, info_log_length, NULL, info_log);

            ERROR("Tessellation Control shader compilation failed: %s", info_log);

            glDeleteShader(tess_control_shader_object);
            FREE(info_log);

            return 0;
        }

        shader_objects[SHADER_TESS_CONTROL] = tess_control_shader_object;
    }

    // Tessellation Evaluation Shader
    if (tess_eval != NULL && strlen(tess_eval) > 0)
    {
        uint32_t tess_eval_shader_object = glCreateShader(GL_TESS_EVALUATION_SHADER);
        glShaderSource(tess_eval_shader_object, 1, (const char * const*)&tess_eval, NULL);
        glCompileShader(tess_eval_shader_object);

        int32_t compile_status;
        glGetShaderiv(tess_eval_shader_object, GL_COMPILE_STATUS, &compile_status);

        if (compile_status == GL_FALSE)
        {
            int32_t info_log_length;
            glGetShaderiv(tess_eval_shader_object, GL_INFO_LOG_LENGTH, &info_log_length);

            int8_t* info_log = (int8_t*)MALLOC(info_log_length);
            glGetShaderInfoLog(tess_eval_shader_object, info_log_length, NULL, info_log);

            ERROR("Tessellation Evaluation shader compilation failed: %s", info_log);

            glDeleteShader(tess_eval_shader_object);
            FREE(info_log);

            return 0;
        }

        shader_objects[SHADER_TESS_EVAL] = tess_eval_shader_object;
    }

    // Compute Shader
    if (compute != NULL && strlen(compute) > 0)
    {
        uint32_t compute_shader_object = glCreateShader(GL_COMPUTE_SHADER);
        glShaderSource(compute_shader_object, 1, (const char * const*)&compute, NULL);
        glCompileShader(compute_shader_object);

        int32_t compile_status;
        glGetShaderiv(compute_shader_object, GL_COMPILE_STATUS, &compile_status);

        if (compile_status == GL_FALSE)
        {
            int32_t info_log_length;
            glGetShaderiv(compute_shader_object, GL_INFO_LOG_LENGTH, &info_log_length);

            int8_t* info_log = (int8_t*)MALLOC(info_log_length);
            glGetShaderInfoLog(compute_shader_object, info_log_length, NULL, info_log);

            ERROR("Compute shader compilation failed: %s", info_log);

            glDeleteShader(compute_shader_object);
            FREE(info_log);

            return 0;
        }

        shader_objects[SHADER_COMPUTE] = compute_shader_object;
    }

    uint32_t program_object = glCreateProgram();

    for (int i = 0; i < 6; i++)
    {
        if (shader_objects[i] != 0)
        {
            glAttachShader(program_object, shader_objects[i]);
        }
    }

    glLinkProgram(program_object);

    for (int i = 0; i < 6; i++)
    {
        if (shader_objects[i] != 0)
        {
            glDetachShader(program_object, shader_objects[i]);
            glDeleteShader(shader_objects[i]);
        }
    }

    int32_t link_status;
    glGetProgramiv(program_object, GL_LINK_STATUS, &link_status);

    if (link_status == GL_FALSE)
    {
        int32_t info_log_length;
        glGetProgramiv(program_object, GL_INFO_LOG_LENGTH, &info_log_length);

        int8_t* info_log = (int8_t*)MALLOC(info_log_length);
        glGetProgramInfoLog(program_object, info_log_length, NULL, info_log);

        ERROR("Program linking failed: %s", info_log);

        glDeleteProgram(program_object);

        for (int i = 0; i < 6; i++)
        {
            if (shader_objects[i] != 0)
            {
                glDeleteShader(shader_objects[i]);
            }
        }

        FREE(info_log);

        return 0;
    }
    
    return program_object;
}

void shader_destroy(shader_t shader)
{
	glDeleteProgram(shader);
}

void shader_bind(shader_t shader)
{
	glUseProgram(shader);
}

void shader_uniform_float32(shader_t shader, const char* uniform_name, float value)
{
    glUniform1f(glGetUniformLocation(shader, uniform_name), value);
}

void shader_uniform_int32(shader_t shader, const char* uniform_name, int32_t value)
{
    glUniform1i(glGetUniformLocation(shader, uniform_name), value);
}

void shader_uniform_uint32(shader_t shader, const char* uniform_name, uint32_t value)
{
    glUniform1ui(glGetUniformLocation(shader, uniform_name), value);
}

void shader_uniform_vec2(shader_t shader, const char* uniform_name, vec2 value)
{
    glUniform2f(glGetUniformLocation(shader, uniform_name), value[0], value[1]);
}

void shader_uniform_vec3(shader_t shader, const char* uniform_name, vec3 value)
{
    glUniform3f(glGetUniformLocation(shader, uniform_name), value[0], value[1], value[2]);
}

void shader_uniform_vec4(shader_t shader, const char* uniform_name, vec4 value)
{
    glUniform4f(glGetUniformLocation(shader, uniform_name), value[0], value[1], value[2], value[3]);
}

void shader_uniform_mat4(shader_t shader, const char* uniform_name, mat4 value)
{
    glUniformMatrix4fv(glGetUniformLocation(shader, uniform_name), 1, GL_FALSE, (const float*)value);
}

void shader_uniform_float32_array(shader_t shader, const char* uniform_name, float* data_ptr, size_t count)
{
	glUniform1fv(glGetUniformLocation(shader, uniform_name), count, data_ptr);
}

void shader_uniform_int32_array(shader_t shader, const char* uniform_name, int32_t* data_ptr, size_t count)
{
	glUniform1iv(glGetUniformLocation(shader, uniform_name), count, data_ptr);
}




mesh_t* mesh_create()
{
	mesh_t* mesh = CALLOC(sizeof(mesh_t));

	glGenVertexArrays(1, &mesh->gl_vertex_array);
	//TODO: needed? glBindVertexArray(mesh->gl_vertexArray);
	glGenBuffers(1, &mesh->gl_vertex_buffer);
	//TODO: needed? glBindBuffer(GL_ARRAY_BUFFER, mesh->gl_vertexBuffer);
	glGenBuffers(1, &mesh->gl_index_buffer);

	//TODO: needed? ff:
	//glBindBuffer(GL_ARRAY_BUFFER, 0);
	//glBindVertexArray(0);
	
	return mesh;
}

void mesh_destroy(mesh_t* mesh)
{
	glDeleteVertexArrays(1, &mesh->gl_vertex_array);
	glDeleteBuffers(1, &mesh->gl_vertex_buffer);
	glDeleteBuffers(1, &mesh->gl_index_buffer);
	
	FREE(mesh);
}

void mesh_set_attributes(mesh_t* mesh, vertex_attribute_e* vertex_attributes, size_t num_attributes)
{
    glBindVertexArray(mesh->gl_vertex_array);
    glBindBuffer(GL_ARRAY_BUFFER, mesh->gl_vertex_buffer);

    //count vertex layout size
    for (size_t i = 0; i < num_attributes; i++)
    {
        switch (vertex_attributes[i])
        {
        case VERTEX_ATTRIB_FLOAT1:
            mesh->vertex_size += sizeof(float);
            break;
        case VERTEX_ATTRIB_FLOAT2:
            mesh->vertex_size += sizeof(float) * 2;
            break;
        case VERTEX_ATTRIB_FLOAT3:
            mesh->vertex_size += sizeof(float) * 3;
            break;
        case VERTEX_ATTRIB_FLOAT4:
            mesh->vertex_size += sizeof(float) * 4;
            break;
        case VERTEX_ATTRIB_INT:
            mesh->vertex_size += sizeof(int);
            break;
        case VERTEX_ATTRIB_UINT:
            mesh->vertex_size += sizeof(uint32_t);
            break;
        case VERTEX_ATTRIB_FLOAT1_NORM:
            mesh->vertex_size += sizeof(GLbyte); // GLbyte for GL_BYTE normalized
            break;
        case VERTEX_ATTRIB_FLOAT2_NORM:
            mesh->vertex_size += sizeof(GLbyte) * 2;
            break;
        case VERTEX_ATTRIB_FLOAT3_NORM:
            mesh->vertex_size += sizeof(GLbyte) * 3;
            break;
        case VERTEX_ATTRIB_FLOAT4_NORM:
            mesh->vertex_size += sizeof(GLbyte) * 4;
            break;
        case VERTEX_ATTRIB_INT_NORM:
            mesh->vertex_size += sizeof(GLint); // GLint for GL_INT normalized
            break;
        case VERTEX_ATTRIB_UINT_NORM:
            mesh->vertex_size += sizeof(GLuint); // GLuint for GL_UNSIGNED_INT normalized
            break;
        default:
            break;
        }
    }


    //apply vertex layout
    size_t offset = 0;
    for (size_t i = 0; i < num_attributes; i++)
    {
        switch (vertex_attributes[i])
        {
        case VERTEX_ATTRIB_FLOAT1:
            glEnableVertexAttribArray(i);
            glVertexAttribPointer(i, 1, GL_FLOAT, GL_FALSE, mesh->vertex_size, (const void*)offset);
            offset += sizeof(float);
            break;
        case VERTEX_ATTRIB_FLOAT2:
            glEnableVertexAttribArray(i);
            glVertexAttribPointer(i, 2, GL_FLOAT, GL_FALSE, mesh->vertex_size, (const void*)offset);
            offset += sizeof(float) * 2;
            break;
        case VERTEX_ATTRIB_FLOAT3:
            glEnableVertexAttribArray(i);
            glVertexAttribPointer(i, 3, GL_FLOAT, GL_FALSE, mesh->vertex_size, (const void*)offset);
            offset += sizeof(float) * 3;
            break;
        case VERTEX_ATTRIB_FLOAT4:
            glEnableVertexAttribArray(i);
            glVertexAttribPointer(i, 4, GL_FLOAT, GL_FALSE, mesh->vertex_size, (const void*)offset);
            offset += sizeof(float) * 4;
            break;
        case VERTEX_ATTRIB_INT:
            glEnableVertexAttribArray(i);
            glVertexAttribIPointer(i, 1, GL_INT, mesh->vertex_size, (const void*)offset);
            offset += sizeof(int);
            break;
        case VERTEX_ATTRIB_UINT:
            glEnableVertexAttribArray(i);
            glVertexAttribIPointer(i, 1, GL_UNSIGNED_INT, mesh->vertex_size, (const void*)offset);
            offset += sizeof(uint32_t);
            break;
        case VERTEX_ATTRIB_FLOAT1_NORM:
            glEnableVertexAttribArray(i);
            glVertexAttribPointer(i, 1, GL_BYTE, GL_TRUE, mesh->vertex_size, (const void*)offset);
            offset += sizeof(GLbyte);
            break;
        case VERTEX_ATTRIB_FLOAT2_NORM:
            glEnableVertexAttribArray(i);
            glVertexAttribPointer(i, 2, GL_BYTE, GL_TRUE, mesh->vertex_size, (const void*)offset);
            offset += sizeof(GLbyte) * 2;
            break;
        case VERTEX_ATTRIB_FLOAT3_NORM:
            glEnableVertexAttribArray(i);
            glVertexAttribPointer(i, 3, GL_BYTE, GL_TRUE, mesh->vertex_size, (const void*)offset);
            offset += sizeof(GLbyte) * 3;
            break;
        case VERTEX_ATTRIB_FLOAT4_NORM:
            glEnableVertexAttribArray(i);
            glVertexAttribPointer(i, 4, GL_BYTE, GL_TRUE, mesh->vertex_size, (const void*)offset);
            offset += sizeof(GLbyte) * 4;
            break;
        case VERTEX_ATTRIB_INT_NORM:
            glEnableVertexAttribArray(i);
            glVertexAttribIPointer(i, 1, GL_INT, mesh->vertex_size, (const void*)offset);
            offset += sizeof(GLint);
            break;
        case VERTEX_ATTRIB_UINT_NORM:
            glEnableVertexAttribArray(i);
            glVertexAttribIPointer(i, 1, GL_UNSIGNED_INT, mesh->vertex_size, (const void*)offset);
            offset += sizeof(GLuint);
            break;
        default:
            break;
        }
    }

    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);
}

void mesh_set_data_vertices(mesh_t* mesh, void* vertices, size_t num_vertices)
{

    glBindBuffer(GL_ARRAY_BUFFER, mesh->gl_vertex_buffer);
    glBufferData(GL_ARRAY_BUFFER, num_vertices * mesh->vertex_size, vertices, GL_STATIC_DRAW);//GL_STREAM_DRAW, STATIC ???
    glBindBuffer(GL_ARRAY_BUFFER, 0);

    mesh->num_vertices = num_vertices;
}

void mesh_set_data_indices(mesh_t* mesh, uint32_t* indices, size_t num_indices)
{
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh->gl_index_buffer);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, num_indices * sizeof(uint32_t), indices, GL_STATIC_DRAW);//GL_STREAM_DRAW, STATIC ???
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);

    mesh->num_indices = num_indices;
}

void mesh_draw(mesh_t* mesh, uint8_t indexed, draw_mode_e draw_mode, uint8_t instanced)
{
    if (instanced)
    {
        ERROR("TODO: IMPLEMENT instanced drawing");
    }
    else
    {
        if (indexed)
        {
            if (mesh->num_vertices == 0 || mesh->num_indices == 0 || mesh->gl_vertex_array == 0) return;

            glBindVertexArray(mesh->gl_vertex_array);
            glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh->gl_index_buffer);
            glDrawElements(draw_mode, mesh->num_indices, GL_UNSIGNED_INT, 0);
            glBindVertexArray(0);
            glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
        }
        else
        {
            if (mesh->num_vertices == 0 || mesh->gl_vertex_array == 0) return;

            glBindVertexArray(mesh->gl_vertex_array);
            glDrawArrays(draw_mode, 0, mesh->num_vertices);
            glBindVertexArray(0);
        }
    }
}



texture_t* texture_create(uint32_t width, uint32_t height, texture_channels_e channels, uint8_t bits_per_channel)
{
	texture_t* texture = MALLOC(sizeof(texture_t));
	glGenTextures(1, &texture->gl_texture);
	texture->width = width;
	texture->height = height;
	texture->channels = channels;

	//only allow 8 and 16 bit
	if(bits_per_channel != 8 && bits_per_channel != 16)
		bits_per_channel = 8;
	texture->bits_per_channel = bits_per_channel;

	texture_resize(texture, width, height);

	texture_filtering(texture, TEXTURE_FILTERING_NEAREST, TEXTURE_FILTERING_NEAREST);
	texture_wrapping(texture, TEXTURE_WRAPPING_REPEAT, TEXTURE_WRAPPING_REPEAT);

	return texture;
}

void texture_destroy(texture_t* texture)
{
	glDeleteTextures(1, &texture->gl_texture);
	FREE(texture);
}

void texture_bind(texture_t* texture, uint32_t slot)
{
	glActiveTexture(GL_TEXTURE0 + slot);
	glBindTexture(GL_TEXTURE_2D, texture->gl_texture);
}

void texture_resize(texture_t* texture, uint32_t width, uint32_t height)
{
	texture_set_pixels(texture, width, height, NULL);
}

void texture_set_pixels(texture_t* texture, uint32_t width, uint32_t height, void* pixels)
{
	int previous_id;
	glGetIntegerv(GL_TEXTURE_BINDING_2D, &previous_id);
	texture_bind(texture, 0);
	//need to be unsigned byte / short!
	glTexImage2D(GL_TEXTURE_2D, 0, texture->channels, width, height, 0, texture->channels, (texture->bits_per_channel == 8) ? GL_UNSIGNED_BYTE : /*else 16bit*/ GL_UNSIGNED_SHORT, pixels);
	texture->width = width;
	texture->height = height;

	glBindTexture(GL_TEXTURE_2D, previous_id);
}

void texture_get_pixels(texture_t* texture, void* pixels)
{
	int previous_id;
	glGetIntegerv(GL_TEXTURE_BINDING_2D, &previous_id);
	texture_bind(texture, 0);
	
	glGetTexImage(GL_TEXTURE_2D, 0, texture->channels, (texture->bits_per_channel == 8) ? GL_UNSIGNED_BYTE : /*else 16bit*/ GL_UNSIGNED_SHORT, pixels);

	glBindTexture(GL_TEXTURE_2D, previous_id);
}

void texture_filtering(texture_t* texture, texture_filtering_e filtering_magnifying, texture_filtering_e filtering_minifying)
{
	int previous_id;
	glGetIntegerv(GL_TEXTURE_BINDING_2D, &previous_id);
	texture_bind(texture, 0);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, filtering_minifying);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, filtering_magnifying);

	glBindTexture(GL_TEXTURE_2D, previous_id);
}

void texture_wrapping(texture_t* texture, texture_wrapping_e wrapping_x, texture_wrapping_e wrapping_y)
{
	int previous_id;
	glGetIntegerv(GL_TEXTURE_BINDING_2D, &previous_id);
	texture_bind(texture, 0);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, wrapping_x);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, wrapping_y);

	glBindTexture(GL_TEXTURE_2D, previous_id);
}

uint32_t texture_get_num_channels(texture_t* texture)
{
	switch(texture->channels)
	{
		case TEXTURE_CHANNELS_R: return 1; break;
		case TEXTURE_CHANNELS_RG: return 2; break;
		case TEXTURE_CHANNELS_RGB: return 3; break;
		case TEXTURE_CHANNELS_RGBA: return 4; break;
		default: return 4; break;
	}
}


render_target_t* render_target_create(uint32_t width, uint32_t height, texture_channels_e channels, uint8_t bits_per_channel)
{
	render_target_t* render_target = MALLOC(sizeof(render_target_t));
	glGenFramebuffers(1, &render_target->gl_framebuffer);
	render_target->texture = texture_create(width, height, channels, bits_per_channel);

	glBindFramebuffer(GL_FRAMEBUFFER, render_target->gl_framebuffer);
	glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, render_target->texture->gl_texture, 0);
	glDrawBuffer(GL_COLOR_ATTACHMENT0);
	if (glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE)
	{
		ERROR("Could not create framebuffer for render_target");
	}
	glBindFramebuffer(GL_FRAMEBUFFER, 0);
	
	return render_target;
}

void render_target_destroy(render_target_t* render_target)
{
	texture_destroy(render_target->texture);
	glDeleteFramebuffers(1, &render_target->gl_framebuffer);
	FREE(render_target);
}

void render_target_bind(render_target_t* render_target)
{
	glBindFramebuffer(GL_FRAMEBUFFER, render_target->gl_framebuffer);
	glViewport(0, 0, render_target->texture->width, render_target->texture->height);
}

void render_target_unbind(vec2 new_viewport)
{
	glBindFramebuffer(GL_FRAMEBUFFER, 0);
	glViewport(0, 0, new_viewport[0], new_viewport[1]);
}

texture_t* render_target_get_texture(render_target_t* render_target)
{
	return render_target->texture;
}



//static memory
static const gl_render_state_t gl_render_state_default = {
	//caps are all disabled by default except GL_DITHER
	.caps = {0/*blend*/, 0/*color logic*/, 0/*cull*/, 0/*dbg out*/, 0/*dbg sync*/, 0/*depth clamp*/, 0/*depth test*/, 1/*dither*/ /*rest 0*/},
	.blend_color = {0, 0, 0, 0},
	.blend_equation_rgb = GL_BLEND_EQ_FUNC_ADD,
	.blend_equation_alpha = GL_BLEND_EQ_FUNC_ADD,
	.blend_func_rgb_src = GL_BLEND_FUNC_ONE,
	.blend_func_rgb_dst = GL_BLEND_FUNC_ZERO,
	.blend_func_alpha_src = GL_BLEND_FUNC_ONE,
	.blend_func_alpha_dst = GL_BLEND_FUNC_ZERO,
	.clamp_read_color = 0,
	.color_mask = {1, 1, 1, 1},
	.cull_face = GL_CULL_FACE_BACK,
	.depth_func = GL_DEPTH_FUNC_LESS,
	.depth_mask = 1,
	.depth_range = {0, 1},
	.front_face_ccw = 1,
	.hints = {2, 2, 2, 2},
	.line_width = 1,
	.logic_op = GL_LOGIC_OP_COPY,
	.point_parameter_fade_threshold_size = 1,
	.point_parameter_sprite_coord_origin = 0,
	.point_size = 1,
	.polygon_mode = GL_POLYGON_MODE_FILL,
	.polygon_offset_factor = 0,
	.polygon_offset_units = 0,
	.sample_coverage_value = 1,
	.sample_coverage_invert = 0,
	.scissor_x = 0,
	.scissor_y = 0,
	.scissor_width = 1920,//TODO match window size
	.scissor_height = 1080,//TODO match window size
	.stencil_func = GL_STENCIL_FUNC_ALWAYS,
	.stencil_func_ref = 0,
	.stencil_func_mask = 1,
	.stencil_mask = 1,
	.stencil_op_sfail = GL_STENCIL_OP_KEEP,
	.stencil_op_dpail = GL_STENCIL_OP_KEEP,
	.stencil_op_dppass = GL_STENCIL_OP_KEEP,
	.viewport_x = 0,
	.viewport_y = 0,
	.viewport_width = 1920,//TODO match window size
	.viewport_height = 1080,//TODO match window size
};
static gl_render_state_t gl_render_state = gl_render_state_default;

gl_render_state_t* gl_state()
{
	return &gl_render_state;
}

#define __state gl_render_state
#define __default gl_render_state_default
#define if_not_matching(attrib) if(__default.attrib != __state.attrib)
#define if_not_matching_or(attrib1, attrib2) if(__default.attrib1 != __state.attrib1 || __default.attrib2 != __state.attrib2)
#define if_not_matching_or3(attrib1, attrib2, attrib3) if(__default.attrib1 != __state.attrib1 || __default.attrib2 != __state.attrib2 || __default.attrib3 != __state.attrib3)
#define if_not_matching_or4(attrib1, attrib2, attrib3, attrib4) if(__default.attrib1 != __state.attrib1 || __default.attrib2 != __state.attrib2 || __default.attrib3 != __state.attrib3 || __default.attrib4 != __state.attrib4)

void gl_render_state_reset()
{
	//caps
	for (gl_cap_e cap = 0; cap < __GL_CAP_COUNT; cap++)
	{
		if_not_matching(caps[cap])
		{
			if(__default.caps[cap])
				glEnable(cap);
			else
				glDisable(cap);
		}
	}

	//blend color
	if_not_matching_or4(blend_color[0], blend_color[1], blend_color[2], blend_color[3])
		glBlendColor(__default.blend_color[0], __default.blend_color[1], __default.blend_color[2], __default.blend_color[3]);
	//blend equation
	if_not_matching_or(blend_equation_rgb, blend_equation_alpha)
		glBlendEquationSeparate(__default.blend_equation_rgb, __default.blend_equation_alpha);
	//blend func
	//if_not_matching_or4(blend_func_rgb_src, blend_func_rgb_dst, blend_func_alpha_src, blend_func_alpha_dst)
	//	glBlendFuncSeparate(__default.blend_func_rgb_src, __default.blend_func_rgb_dst, __default.blend_func_alpha_src, __default.blend_func_alpha_dst);
	if_not_matching(blend_func_rgb_src)
		glBlendFunc(GL_SRC_COLOR, __default.blend_func_rgb_src);
	if_not_matching(blend_func_rgb_dst)
		glBlendFunc(GL_DST_COLOR, __default.blend_func_rgb_dst);
	if_not_matching(blend_func_alpha_src)
		glBlendFunc(GL_SRC_ALPHA, __default.blend_func_alpha_src);
	if_not_matching(blend_func_alpha_dst)
		glBlendFunc(GL_DST_ALPHA, __default.blend_func_alpha_dst);
	//clamp color
	if_not_matching(clamp_read_color)
		glClampColor(GL_CLAMP_READ_COLOR, __default.clamp_read_color);
	//color mask
	if_not_matching_or4(color_mask[0], color_mask[1], color_mask[2], color_mask[3])
		glColorMask(__default.color_mask[0], __default.color_mask[1], __default.color_mask[2], __default.color_mask[3]);
	//cull face
	if_not_matching(cull_face)
		glCullFace(__default.cull_face);
	//depth func
	if_not_matching(depth_func)
		glDepthFunc(__default.depth_func);
	//depth mask
	if_not_matching(depth_mask)
		glDepthMask(__default.depth_mask);
	//depth range
	if_not_matching_or(depth_range[0], depth_range[1])
		glDepthRangef(__default.depth_range[0], __default.depth_range[1]);
	//front face ccw
	if_not_matching(front_face_ccw)
	{
		if(__default.front_face_ccw == 1)
			glFrontFace(GL_CCW);
		else
			glFrontFace(GL_CW);
	}
	//hints
	for (gl_hint_e hint = 0; hint < __GL_HINT_COUNT; hint++)
	{
		if_not_matching(hints[hint])
			switch (__default.hints[hint])
			{
				case 0:
					glHint(hint, GL_FASTEST); break;
				case 1:
					glHint(hint, GL_NICEST); break;
				case 2:
					glHint(hint, GL_DONT_CARE); break;
			}
	}
	//line width
	if_not_matching(line_width)
		glLineWidth(__default.line_width);
	//logic_op
	if_not_matching(logic_op)
		glLogicOp(__default.logic_op);
	//point param threshold size
	if_not_matching(point_parameter_fade_threshold_size)
		glPointParameterf(GL_POINT_FADE_THRESHOLD_SIZE, __default.point_parameter_fade_threshold_size);
	//point param sprite coord origin
	if_not_matching(point_parameter_sprite_coord_origin)
	{
		if(__default.point_parameter_sprite_coord_origin == 0)
			glPointParameterf(GL_POINT_SPRITE_COORD_ORIGIN, GL_UPPER_LEFT);
		else
			glPointParameterf(GL_POINT_SPRITE_COORD_ORIGIN, GL_LOWER_LEFT);
	}
	//point size
	if_not_matching(point_size)
		glPointSize(__default.point_size);
	//polygon mode
	if_not_matching(polygon_mode)
		glPolygonMode(GL_FRONT_AND_BACK, __default.polygon_mode);
	//polygon offset
	if_not_matching_or(polygon_offset_factor, polygon_offset_units)
		glPolygonOffset(__default.polygon_offset_factor, __default.polygon_offset_units);
	//sample coverage value
	if_not_matching_or(sample_coverage_value, sample_coverage_invert)
		glSampleCoverage(__default.sample_coverage_value, __default.sample_coverage_invert);
	//scissor
	if_not_matching_or4(scissor_x, scissor_y, scissor_width, scissor_height)
		glScissor(__default.scissor_x, __default.scissor_y, __default.scissor_width, __default.scissor_height);
	//stencil func
	if_not_matching_or3(stencil_func, stencil_func_ref, stencil_func_mask)
		glStencilFunc(__default.stencil_func, __default.stencil_func_ref, __default.stencil_func_mask);
	//stencil mask
	if_not_matching(stencil_mask)
		glStencilMask(__default.stencil_mask);
	//stencil op
	if_not_matching_or3(stencil_op_sfail, stencil_op_dpail, stencil_op_dppass)
		glStencilOp(__default.stencil_op_sfail, __default.stencil_op_dpail, __default.stencil_op_dppass);
	//viewport
	if_not_matching_or4(viewport_x, viewport_y, viewport_width, viewport_height)
		glViewport(__default.viewport_x, __default.viewport_y, __default.viewport_width, __default.viewport_height);
	
	gl_render_state = __default;
}

void gl_render_state_apply()
{
	//caps
	for (gl_cap_e cap = 0; cap < __GL_CAP_COUNT; cap++)
	{
		if_not_matching(caps[cap])
		{
			if(__state.caps[cap])
				glEnable(cap);
			else
				glDisable(cap);
		}
	}

	//blend color
	if_not_matching_or4(blend_color[0], blend_color[1], blend_color[2], blend_color[3])
		glBlendColor(__state.blend_color[0], __state.blend_color[1], __state.blend_color[2], __state.blend_color[3]);
	//blend equation
	if_not_matching_or(blend_equation_rgb, blend_equation_alpha)
		glBlendEquationSeparate(__state.blend_equation_rgb, __state.blend_equation_alpha);
	//blend func
	//if_not_matching_or4(blend_func_rgb_src, blend_func_rgb_dst, blend_func_alpha_src, blend_func_alpha_dst)
	//	glBlendFuncSeparate(__state.blend_func_rgb_src, __state.blend_func_rgb_dst, __state.blend_func_alpha_src, __state.blend_func_alpha_dst);
	if_not_matching(blend_func_rgb_src)
		glBlendFunc(GL_SRC_COLOR, __state.blend_func_rgb_src);
	if_not_matching(blend_func_rgb_dst)
		glBlendFunc(GL_DST_COLOR, __state.blend_func_rgb_dst);
	if_not_matching(blend_func_alpha_src)
		glBlendFunc(GL_SRC_ALPHA, __state.blend_func_alpha_src);
	if_not_matching(blend_func_alpha_dst)
		glBlendFunc(GL_DST_ALPHA, __state.blend_func_alpha_dst);

	//clamp color
	if_not_matching(clamp_read_color)
		glClampColor(GL_CLAMP_READ_COLOR, __state.clamp_read_color);
	//color mask
	if_not_matching_or4(color_mask[0], color_mask[1], color_mask[2], color_mask[3])
		glColorMask(__state.color_mask[0], __state.color_mask[1], __state.color_mask[2], __state.color_mask[3]);
	//cull face
	if_not_matching(cull_face)
		glCullFace(__state.cull_face);
	//depth func
	if_not_matching(depth_func)
		glDepthFunc(__state.depth_func);
	//depth mask
	if_not_matching(depth_mask)
		glDepthMask(__state.depth_mask);
	//depth range
	if_not_matching_or(depth_range[0], depth_range[1])
		glDepthRangef(__state.depth_range[0], __state.depth_range[1]);
	//front face ccw
	if_not_matching(front_face_ccw)
	{
		if(__state.front_face_ccw == 1)
			glFrontFace(GL_CCW);
		else
			glFrontFace(GL_CW);
	}
	//hints
	for (gl_hint_e hint = 0; hint < __GL_HINT_COUNT; hint++)
	{
		if_not_matching(hints[hint])
			switch (__state.hints[hint])
			{
				case 0:
					glHint(hint, GL_FASTEST); break;
				case 1:
					glHint(hint, GL_NICEST); break;
				case 2:
					glHint(hint, GL_DONT_CARE); break;
			}
	}
	//line width
	if_not_matching(line_width)
		glLineWidth(__state.line_width);
	//logic_op
	if_not_matching(logic_op)
		glLogicOp(__state.logic_op);
	//point param threshold size
	if_not_matching(point_parameter_fade_threshold_size)
		glPointParameterf(GL_POINT_FADE_THRESHOLD_SIZE, __state.point_parameter_fade_threshold_size);
	//point param sprite coord origin
	if_not_matching(point_parameter_sprite_coord_origin)
	{
		if(__state.point_parameter_sprite_coord_origin == 0)
			glPointParameterf(GL_POINT_SPRITE_COORD_ORIGIN, GL_UPPER_LEFT);
		else
			glPointParameterf(GL_POINT_SPRITE_COORD_ORIGIN, GL_LOWER_LEFT);
	}
	//point size
	if_not_matching(point_size)
		glPointSize(__state.point_size);
	//polygon mode
	if_not_matching(polygon_mode)
		glPolygonMode(GL_FRONT_AND_BACK, __state.polygon_mode);
	//polygon offset
	if_not_matching_or(polygon_offset_factor, polygon_offset_units)
		glPolygonOffset(__state.polygon_offset_factor, __state.polygon_offset_units);
	//sample coverage value
	if_not_matching_or(sample_coverage_value, sample_coverage_invert)
		glSampleCoverage(__state.sample_coverage_value, __state.sample_coverage_invert);
	//scissor
	if_not_matching_or4(scissor_x, scissor_y, scissor_width, scissor_height)
		glScissor(__state.scissor_x, __state.scissor_y, __state.scissor_width, __state.scissor_height);
	//stencil func
	if_not_matching_or3(stencil_func, stencil_func_ref, stencil_func_mask)
		glStencilFunc(__state.stencil_func, __state.stencil_func_ref, __state.stencil_func_mask);
	//stencil mask
	if_not_matching(stencil_mask)
		glStencilMask(__state.stencil_mask);
	//stencil op
	if_not_matching_or3(stencil_op_sfail, stencil_op_dpail, stencil_op_dppass)
		glStencilOp(__state.stencil_op_sfail, __state.stencil_op_dpail, __state.stencil_op_dppass);
	//viewport
	if_not_matching_or4(viewport_x, viewport_y, viewport_width, viewport_height)
		glViewport(__state.viewport_x, __state.viewport_y, __state.viewport_width, __state.viewport_height);
}

