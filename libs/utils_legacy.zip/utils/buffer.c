#include "buffer.h"
#include "logging.h"

#include <string.h>

//TODO: fix this
#include <stdlib.h>
#define MALLOC malloc
#define REALLOC realloc
#define FREE free
//

buffer_t* buffer_create()
{
	buffer_t* buffer = MALLOC(sizeof(buffer_t));
	buffer->size = 0;
	buffer->data = NULL;
	buffer->read_offset = 0;

	return buffer;
}

void buffer_destroy(buffer_t* buffer)
{
	buffer_free_data(buffer);
	FREE(buffer);
}

void buffer_copy_data(buffer_t* buffer, void* data, size_t size)
{
	buffer_reserve_memory(buffer, size);
	memcpy(buffer->data, data, size);
}

void buffer_reserve_memory(buffer_t* buffer, size_t size)
{
	buffer->data = REALLOC(buffer->data, size);
	buffer->size = size;
}

void buffer_free_data(buffer_t* buffer)
{
	if(buffer->data)
		FREE(buffer->data);
	buffer->size = 0;
}

void buffer_load_data_from_file(buffer_t* buffer, const char* filename)
{
	FILE *file = fopen(filename, "rb");
	buffer_load_data_from_file_ptr(buffer, file);
	fclose(file);
}

void buffer_load_data_from_file_ptr(buffer_t* buffer, FILE* file)
{
	fseek(file, 0, SEEK_END);
	long file_size = ftell(file);
	fseek(file, 0, SEEK_SET);
	
	buffer_reserve_memory(buffer, file_size);
	fread(buffer->data, file_size, 1, file);
}

uint8_t check_for_read_offset_overflow(buffer_t* buffer, size_t tried_offset)//returns 1 on error
{
	if(buffer->read_offset + tried_offset > buffer->size)
	{
		ERROR("Buffer read out of bounds! (You reached the end of the buffer)");
		return 1;
	}
	return 0;
}

void buffer_set_offset(buffer_t* buffer, size_t new_offset)
{
	if(new_offset > buffer->size)
	{
		ERROR("Could not set new_offset for buffer!");
	}
	else
		buffer->read_offset = new_offset;
}

void* buffer_read(buffer_t* buffer, size_t size)
{
	if(!check_for_read_offset_overflow(buffer, size))
	{
		void* ptr = buffer->data + buffer->read_offset;
		buffer->read_offset += size;
		return ptr;
	}
	else
		return NULL;
}

uint8_t buffer_read_uint8(buffer_t* buffer)
{
	if(!check_for_read_offset_overflow(buffer, sizeof(uint8_t)))
		return *(uint8_t*)buffer_read(buffer, sizeof(uint8_t));
	return 0;
}

int8_t buffer_read_int8(buffer_t* buffer)
{
	if(!check_for_read_offset_overflow(buffer, sizeof(int8_t)))
		return *(int8_t*)buffer_read(buffer, sizeof(int8_t));
	return 0;
}

uint16_t buffer_read_uint16(buffer_t* buffer)
{
	if(!check_for_read_offset_overflow(buffer, sizeof(uint16_t)))
		return *(uint16_t*)buffer_read(buffer, sizeof(uint16_t));
	return 0;
}

int16_t buffer_read_int16(buffer_t* buffer)
{
	if(!check_for_read_offset_overflow(buffer, sizeof(int16_t)))
		return *(int16_t*)buffer_read(buffer, sizeof(int16_t));
	return 0;
}

uint32_t buffer_read_uint32(buffer_t* buffer)
{
	if(!check_for_read_offset_overflow(buffer, sizeof(uint32_t)))
		return *(uint32_t*)buffer_read(buffer, sizeof(uint32_t));
	return 0;
}

int32_t buffer_read_int32(buffer_t* buffer)
{
	if(!check_for_read_offset_overflow(buffer, sizeof(int32_t)))
		return *(int32_t*)buffer_read(buffer, sizeof(int32_t));
	return 0;
}

uint64_t buffer_read_uint64(buffer_t* buffer)
{
	if(!check_for_read_offset_overflow(buffer, sizeof(uint64_t)))
		return *(uint64_t*)buffer_read(buffer, sizeof(uint64_t));
	return 0;
}

int64_t buffer_read_int64(buffer_t* buffer)
{
	if(!check_for_read_offset_overflow(buffer, sizeof(int64_t)))
		return *(int64_t*)buffer_read(buffer, sizeof(int64_t));
	return 0;
}

float buffer_read_f32(buffer_t* buffer)
{
	if(!check_for_read_offset_overflow(buffer, sizeof(float)))
		return *(float*)buffer_read(buffer, sizeof(float));
	return 0.0f;
}

double buffer_read_f64(buffer_t* buffer)
{
	if(!check_for_read_offset_overflow(buffer, sizeof(double)))
		return *(double*)buffer_read(buffer, sizeof(double));
	return 0.0;
}
