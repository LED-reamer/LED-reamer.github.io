//linux only

#pragma once
#include <stdint.h>

#define WEB_SERVER_BUFFER_SIZE 1024 * 1024
#define WEB_SERVER_MAX_ROUTES 1000

typedef struct web_server_t web_server_t;

typedef enum
{
	METHOD_GET,
	METHOD_HEAD,
	METHOD_POST,
	METHOD_PUT,
	METHOD_DELETE,
	METHOD_CONNECT,
	METHOD_OPTIONS,
	METHOD_TRACE,
}web_server_method_e;

typedef struct
{
	char receive_buffer[WEB_SERVER_BUFFER_SIZE];
}web_server_route_args_t;

typedef struct
{
	char send_buffer[WEB_SERVER_BUFFER_SIZE];
}web_server_route_response_t;

void web_server_init();
void web_server_terminate();

web_server_t* web_server_create();
void web_server_add_route(web_server_t* web_server, web_server_method_e method, const char* route, void (*function)(web_server_route_args_t*, web_server_route_response_t*));
void web_server_start(web_server_t* web_server, uint32_t port);
void web_server_stop(web_server_t* web_server);
uint8_t web_server_running(web_server_t* web_server);
void web_server_destroy(web_server_t* web_server);
