#pragma once
#include "color.h"
#include <cglm/cglm.h>

typedef struct
{
	color_t color_0;//root
	color_t color_1;//1. child
	color_t color_2;//...
	color_t color_3;
	color_t color_4;
	color_t color_5;
	float rounding;
	float padding_top, padding_bottom, padding_left, padding_right;
}ui_container_style_t;

typedef struct
{
	color_t font_color;
	ui_container_style_t container_style;
}ui_style_t;

typedef enum
{
	UI_VERTICAL,
	UI_HORIZONTAL,
}ui_orientation_e;

typedef struct
{
	uint32_t index;
	
	uint32_t parent;
	uint32_t* children;//dynamic_array
	uint32_t child_depth;
	float children_weight;
	float weight;
	
	ui_orientation_e orientation;
	vec4 rectangle;
	ui_style_t* style;
}ui_container_t;

typedef struct
{
	ui_style_t style_default;
	
	ui_container_t* containers;//dynamic_array
}ui_t;

ui_style_t ui_style_get_default_dark();

ui_t* ui_init();
void ui_update(ui_t* ui, vec4 root_container_rectangle);
void ui_destroy(ui_t* ui);

uint32_t ui_container_add(ui_t* ui, uint32_t parent/*0 -> root*/, ui_orientation_e orientation, float weight, ui_style_t* style/*nullable*/);
