#include "http.h"

#include <string.h>
#include <stdio.h>

//TODO fix this
#include <stdlib.h>
#define MALLOC malloc
#define REALLOC realloc
#define FREE free
//

/*
example:

POST /cgi-bin/process.cgi HTTP/1.1
User-Agent: Mozilla/4.0 (compatible; MSIE5.01; Windows NT)
Host: www.tutorialspoint.com
Content-Type: application/x-www-form-urlencoded
Content-Length: length
Accept-Language: en-us
Accept-Encoding: gzip, deflate
Connection: Keep-Alive

*/

void http_free(http_request_t* http_request)
{
	//header
	FREE(http_request->request_uri);
	FREE(http_request->http_version);

	
	for(size_t i = 0; i < http_request->field_count; i++)
	{
		FREE(http_request->header_fields[i].field);
		FREE(http_request->header_fields[i].data);
	}
	FREE(http_request->header_fields);
	
	//body
	FREE(http_request->data);
}


static const struct {
    http_request_method_e method;
    const char *str;
} __method_enum_conversion [] = {
    {HTTP_GET, "GET"},
    {HTTP_HEAD, "HEAD"},
    {HTTP_POST, "POST"},
    {HTTP_PUT, "PUT"},
    {HTTP_DELETE, "DELETE"},
    {HTTP_CONNECT, "CONNECT"},
    {HTTP_OPTIONS, "OPTIONS"},
    {HTTP_TRACE, "TRACE"},
};

http_request_method_e str_to_method_enum(char *str)
{
	for (int i = 0;  i < (int)(sizeof(__method_enum_conversion) / sizeof (__method_enum_conversion[0]));  ++i)
    	if (!strcmp (str, __method_enum_conversion[i].str))
     		return __method_enum_conversion[i].method;
	//if error return GET or 0
    return HTTP_GET;
}

int __parse_request_line(char* request_string, http_request_t* request)
{
	char* token = strtok(request_string, " ");
	
	if(token == NULL) return 0;
	
	unsigned char token_index = 0;
	while (token != NULL && token_index < 3)
	{
		switch(token_index)
		{
			case 0:
				request->method = str_to_method_enum(token);
				break;
			case 1:
				request->request_uri = MALLOC(strlen(token)+1);
				strncpy(request->request_uri, token, strlen(token));
				request->request_uri[strlen(token)] = '\0';
				break;
			case 2:
				char* sub_token = strtok(token, "\r\n");
				if(sub_token == NULL) return 0;
				request->http_version = MALLOC(strlen(sub_token)+1);
				strncpy(request->http_version, sub_token, strlen(sub_token));
				request->http_version[strlen(sub_token)] = '\0';
				break;
		}
		token = strtok(NULL, " ");
		token_index++;
	}
	return 1;
}

int __parse_header_fields(char* request_string, http_request_t* request)
{
	char* end_of_header = strstr(request_string, "\r\n\r\n");
	
	if(end_of_header == NULL) end_of_header = request_string + strlen(request_string);//no body

	char* token = strtok(request_string, "\r\n");
	if(token == NULL) return 0;
		
	unsigned char token_index = 0;
	while (token != NULL)
	{
		if(token_index != 0 && token < end_of_header)
		{
			request->field_count++;
			request->header_fields = REALLOC(request->header_fields, sizeof(http_header_field_t) * request->field_count);
			
			char* end_of_field_name = strchr(token, ':');
			size_t field_name_size = end_of_field_name - token;
			request->header_fields[request->field_count-1].field = MALLOC(field_name_size+1);
			strncpy(request->header_fields[request->field_count-1].field, token, field_name_size);
			request->header_fields[request->field_count-1].field[field_name_size] = '\0';

			size_t field_data_size = (token + strlen(token)) - (end_of_field_name+2);
			request->header_fields[request->field_count-1].data = MALLOC(field_data_size+1);
			strncpy(request->header_fields[request->field_count-1].data, end_of_field_name+2, field_data_size);
			request->header_fields[request->field_count-1].data[field_data_size] = '\0';
		}
		
		token = strtok(NULL, "\r\n");
		token_index++;
	}
	return 1;
}

int __parse_body(char* request_string, http_request_t* request)
{
	char* start_body = strstr(request_string, "\r\n\r\n") + 4;

	if(start_body-4 == NULL) { request->data = NULL; return 1; } //no body //TODO check if -4 is needed in this line
	
	size_t body_size = (request_string + strlen(request_string)) - (start_body);
	request->body_size = body_size+1;
	request->data = MALLOC(request->body_size);
	strncpy(request->data, start_body, body_size);
	request->data[request->body_size - 1] = '\0';
	return 1;
}

http_request_t http_parse(char* request_string)
{
	http_request_t request = { 0 };
	//header
	
	char* request_string_copy = strndup(request_string, strlen(request_string));
	int result = __parse_request_line(request_string_copy, &request);
	FREE(request_string_copy);
	if(!result)
		return request;
		

	request_string_copy = strdup(request_string);
	result = __parse_header_fields(request_string_copy, &request);
	FREE(request_string_copy);
	if(!result)
		return request;

	request_string_copy = strdup(request_string);
	result = __parse_body(request_string_copy, &request);
	FREE(request_string_copy);
	if(!result)
		return request;
		
	return request;
}

char* http_get_header_field(http_request_t* http_request, char* type)
{
	for(size_t i = 0; i < http_request->field_count; i++)
	{
		if(strncmp(http_request->header_fields[i].field, type, strlen(type)) == 0)
		{
			return http_request->header_fields[i].data;
		}
	}

	return NULL;
}
