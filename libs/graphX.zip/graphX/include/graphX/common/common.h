#pragma once
#include "graphX/common/mathHelper.h"

//general
#include <fstream>
#include <vector>

namespace gx
{
    namespace common
    {
        std::vector<glm::vec2> triangulatePolygon(std::vector<glm::vec2> points);
        std::vector<glm::vec2> triangulatePolygon(glm::vec2* points, size_t size);

        template<typename T>
        void saveToFile(T obj, std::string filename)
        {
            std::ofstream file(filename, std::ios::binary);
            if (!file)
                return;

            file.write(reinterpret_cast<const char*>(&obj), sizeof(obj));

            if (!file)
                return;
        }

        template<typename T>
        T loadFromFile(std::string filename) {
            T obj;
            std::ifstream file(filename, std::ios::binary);
            if (file) {
                file.read(reinterpret_cast<char*>(&obj), sizeof(T));
            }
            file.close();
            return obj;
        }
    }
}
