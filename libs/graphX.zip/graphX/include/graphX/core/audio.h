#pragma once

#include "graphX/core/types.h"

#include <string>
#include <optional>


namespace gx
{
	namespace audio
	{
		gx::Sound loadWAV(std::string path);
		void play(gx::Sound* sound);
		void stop(gx::Sound* sound);


		enum SourceAttribute
		{
			pitch,
			gain,
			position,
			velocity,
			direction,
			maxDistance,
			distanceLoss,
			coneOuterGain,
			coneInnerAngle,
			coneOuterAngle,
			doppler,
			dopplerVelocity,
			secondsOffset,
			looping,
		};

		void setAttributes(gx::Sound* sound, std::vector<std::pair<SourceAttribute, glm::vec3>> attributes);
		bool isPlaying(gx::Sound* sound);
	}
}